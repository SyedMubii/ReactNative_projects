import * as React from "react";
import { StyleSheet, View, Image, Text, Pressable } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const ProfileAddress = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.profileAddress}>
      <View style={styles.dealsSection}>
        <View style={[styles.g1, styles.g1Layout]}>
          <View style={styles.rectangleParent}>
            <View style={[styles.frameChild, styles.buttonLayout]} />
            <Image
              style={styles.vectorIcon}
              resizeMode="cover"
              source={require("../assets/vector10.png")}
            />
          </View>
          <Text style={styles.hyderChowkNear}>Hyder chowk near HBL</Text>
          <Text style={[styles.qasimChowk, styles.qasimChowkTypo]}>
            Qasim Chowk
          </Text>
          <Image
            style={[styles.vectorIcon1, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/vector51.png")}
          />
        </View>
        <View style={[styles.g11, styles.g1Layout]}>
          <View style={styles.rectangleParent}>
            <View style={[styles.frameChild, styles.buttonLayout]} />
            <Image
              style={styles.vectorIcon}
              resizeMode="cover"
              source={require("../assets/vector10.png")}
            />
          </View>
          <Text style={styles.hyderChowkNear}>Hyder chowk near HBL</Text>
          <Text style={[styles.parentHouse, styles.qasimChowkTypo]}>
            Parent House
          </Text>
          <Image
            style={[styles.vectorIcon1, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/vector51.png")}
          />
        </View>
        <View style={[styles.g12, styles.g1Layout]}>
          <View style={styles.rectangleParent}>
            <View style={[styles.frameChild, styles.buttonLayout]} />
            <Image
              style={styles.vectorIcon}
              resizeMode="cover"
              source={require("../assets/vector10.png")}
            />
          </View>
          <Text style={styles.hyderChowkNear}>Hyder chowk near HBL</Text>
          <Text style={[styles.parentHouse, styles.qasimChowkTypo]}>
            Appartment
          </Text>
          <Image
            style={[styles.vectorIcon1, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/vector51.png")}
          />
        </View>
        <View style={[styles.g13, styles.g1Layout]}>
          <View style={styles.rectangleParent}>
            <View style={[styles.frameChild, styles.buttonLayout]} />
            <Image
              style={styles.vectorIcon}
              resizeMode="cover"
              source={require("../assets/vector10.png")}
            />
          </View>
          <Text style={styles.hyderChowkNear}>Hyder chowk near HBL</Text>
          <Text style={[styles.parentHouse, styles.qasimChowkTypo]}>
            Office
          </Text>
          <Image
            style={[styles.vectorIcon1, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/vector51.png")}
          />
        </View>
        <View style={[styles.g14, styles.g14Position]}>
          <View style={styles.rectangleParent}>
            <View style={[styles.frameChild, styles.buttonLayout]} />
            <Image
              style={styles.vectorIcon}
              resizeMode="cover"
              source={require("../assets/vector10.png")}
            />
          </View>
          <Text style={styles.hyderChowkNear}>Hyder chowk near HBL</Text>
          <Text style={[styles.parentHouse, styles.qasimChowkTypo]}>Home</Text>
          <Image
            style={[styles.vectorIcon1, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/vector51.png")}
          />
        </View>
      </View>
      <View style={styles.profileIcons}>
        <Text style={[styles.address, styles.g14Position]}>Address</Text>
        <Pressable
          style={styles.vector}
          onPress={() => navigation.navigate("ProfilePage")}
        >
          <Image
            style={[styles.icon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/vector52.png")}
          />
        </Pressable>
      </View>
      <LinearGradient
        style={[styles.button, styles.buttonLayout]}
        locations={[0, 1]}
        colors={["rgba(240, 0, 0, 0.96)", "#dc281e"]}
        useAngle={true}
        angle={90}
      >
        <Text style={[styles.addNewAddress, styles.statusBarPosition]}>
          Add New Address
        </Text>
      </LinearGradient>
      <View style={[styles.statusBar, styles.statusBarPosition]}>
        <View style={styles.action}>
          <Text style={[styles.time, styles.g14Position]}>9:41</Text>
        </View>
        <Image
          style={styles.containerIcon}
          resizeMode="cover"
          source={require("../assets/container.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  g1Layout: {
    height: 112,
    borderWidth: 2,
    borderColor: Color.colorDarkslategray_100,
    borderStyle: "solid",
    borderRadius: Border.br_xl,
    left: 0,
    width: 390,
  },
  buttonLayout: {
    height: 54,
    position: "absolute",
  },
  qasimChowkTypo: {
    color: Color.colorGray_500,
    fontSize: FontSize.size_2xl,
    top: 32,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    textAlign: "left",
    lineHeight: 30,
    left: 128,
    position: "absolute",
  },
  iconLayout: {
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
  },
  g14Position: {
    top: 0,
    position: "absolute",
  },
  statusBarPosition: {
    left: "50%",
    position: "absolute",
  },
  frameChild: {
    top: 7,
    left: 7,
    backgroundColor: Color.colorCrimson,
    width: 54,
    borderRadius: Border.br_16xl,
  },
  vectorIcon: {
    marginTop: -13,
    marginLeft: -9,
    width: 19,
    height: 25,
    left: "50%",
    top: "50%",
    position: "absolute",
  },
  rectangleParent: {
    top: 25,
    left: 41,
    backgroundColor: Color.ew,
    width: 68,
    height: 68,
    borderRadius: Border.br_16xl,
    position: "absolute",
  },
  hyderChowkNear: {
    top: 54,
    fontSize: FontSize.size_smi,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    color: Color.colorDimgray_200,
    width: 145,
    textAlign: "left",
    lineHeight: 30,
    left: 128,
    height: 25,
    position: "absolute",
  },
  qasimChowk: {
    width: 159,
  },
  vectorIcon1: {
    height: "25%",
    width: "7.18%",
    top: "37.5%",
    right: "8.46%",
    bottom: "37.5%",
    left: "84.36%",
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  g1: {
    top: 520,
    position: "absolute",
  },
  parentHouse: {
    width: 145,
  },
  g11: {
    top: 390,
    position: "absolute",
  },
  g12: {
    top: 260,
    position: "absolute",
  },
  g13: {
    top: 130,
    position: "absolute",
  },
  g14: {
    height: 112,
    borderWidth: 2,
    borderColor: Color.colorDarkslategray_100,
    borderStyle: "solid",
    borderRadius: Border.br_xl,
    left: 0,
    width: 390,
  },
  dealsSection: {
    top: 151,
    left: 19,
    height: 632,
    width: 390,
    position: "absolute",
  },
  address: {
    left: 39,
    fontSize: FontSize.iOSDefaultTitle2_size,
    color: Color.colorGray_400,
    display: "flex",
    alignItems: "center",
    width: 202,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    top: 0,
    textAlign: "left",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  vector: {
    left: "0%",
    top: "16.18%",
    right: "90.92%",
    bottom: "15.79%",
    width: "9.08%",
    height: "68.04%",
    position: "absolute",
  },
  profileIcons: {
    top: 81,
    left: 26,
    width: 241,
    height: 33,
    position: "absolute",
  },
  addNewAddress: {
    marginLeft: -90.5,
    top: 12,
    fontSize: FontSize.size_xl,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: Color.iOSFFFFFF,
    textAlign: "left",
  },
  button: {
    top: 852,
    left: 53,
    borderRadius: Border.br_17xl,
    width: 321,
    backgroundColor: "transparent",
  },
  time: {
    fontSize: FontSize.size_mini,
    letterSpacing: 0,
    lineHeight: 18,
    color: Color.ew,
    textAlign: "center",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    top: 0,
    width: 54,
    left: 0,
  },
  action: {
    top: 14,
    left: 20,
    height: 18,
    width: 54,
    position: "absolute",
  },
  containerIcon: {
    marginTop: -5.84,
    right: 15,
    width: 67,
    height: 12,
    top: "50%",
    position: "absolute",
  },
  statusBar: {
    marginLeft: -183,
    top: 9,
    width: 375,
    height: 44,
  },
  profileAddress: {
    backgroundColor: Color.iOSFFFFFF,
    flex: 1,
    height: 975,
    width: "100%",
  },
});

export default ProfileAddress;
