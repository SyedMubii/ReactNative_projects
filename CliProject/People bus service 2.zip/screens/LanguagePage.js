import * as React from "react";
import { Text, StyleSheet, Image, View } from "react-native";
import { Color, FontSize, FontFamily } from "../GlobalStyles";

const LanguagePage = () => {
  return (
    <View style={styles.languagePage}>
      <View style={[styles.languages, styles.englishLayout]}>
        <View style={[styles.japanese, styles.englishLayout]}>
          <Text style={[styles.japanese1, styles.languageFlexBox]}>
            Japanese
          </Text>
          <Image
            style={[styles.icon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/9.png")}
          />
        </View>
        <View style={[styles.russian, styles.englishLayout]}>
          <Text style={[styles.russian1, styles.languageFlexBox]}>Russian</Text>
          <Image
            style={[styles.icon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/9.png")}
          />
        </View>
        <View style={[styles.arabic, styles.englishLayout]}>
          <Text style={[styles.russian1, styles.languageFlexBox]}>Arabic</Text>
          <Image
            style={[styles.icon2, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/7.png")}
          />
        </View>
        <View style={[styles.french, styles.englishLayout]}>
          <Text style={[styles.russian1, styles.languageFlexBox]}>French</Text>
          <Image
            style={[styles.icon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/9.png")}
          />
        </View>
        <View style={[styles.spanish, styles.englishLayout]}>
          <Text style={[styles.russian1, styles.languageFlexBox]}>Spanish</Text>
          <Image
            style={[styles.icon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/9.png")}
          />
        </View>
        <View style={[styles.hindhi, styles.englishLayout]}>
          <Text style={[styles.russian1, styles.languageFlexBox]}>Hindhi</Text>
          <Image
            style={[styles.icon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/9.png")}
          />
        </View>
        <View style={[styles.urdu, styles.englishLayout]}>
          <Text style={[styles.urdu1, styles.languageFlexBox]}>{`Urdu `}</Text>
          <Image
            style={[styles.icon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/9.png")}
          />
        </View>
        <Text style={[styles.language, styles.languageTypo]}>Language</Text>
      </View>
      <View style={[styles.suggested, styles.englishLayout]}>
        <View style={[styles.englishUk, styles.englishLayout]}>
          <Text style={[styles.englishUk1, styles.englishPosition]}>
            English (UK)
          </Text>
          <Image
            style={[styles.icon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/9.png")}
          />
        </View>
        <View style={[styles.englishUs, styles.englishLayout]}>
          <Text style={[styles.englishUs1, styles.englishPosition]}>
            English (US)
          </Text>
          <Image
            style={[styles.icon8, styles.icon8Position]}
            resizeMode="cover"
            source={require("../assets/1.png")}
          />
        </View>
        <Text style={[styles.suggested1, styles.englishPosition]}>
          Suggested
        </Text>
      </View>
      <View style={styles.language1}>
        <Image
          style={styles.vectorIcon}
          resizeMode="cover"
          source={require("../assets/vector38.png")}
        />
        <Text style={[styles.language2, styles.timeTypo]}>Language</Text>
      </View>
      <View style={[styles.statusBar, styles.icon8Position]}>
        <View style={[styles.action, styles.timeLayout]}>
          <Text style={[styles.time, styles.timeLayout]}>9:41</Text>
        </View>
        <Image
          style={styles.containerIcon}
          resizeMode="cover"
          source={require("../assets/container.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  englishLayout: {
    width: 369,
    position: "absolute",
  },
  languageFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  iconLayout: {
    height: 19,
    width: 19,
    top: 1,
  },
  languageTypo: {
    height: 33,
    color: Color.colorTomato_300,
    fontSize: FontSize.size_xl,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
  },
  englishPosition: {
    width: 131,
    textAlign: "left",
    top: 0,
    left: 0,
    position: "absolute",
  },
  icon8Position: {
    left: "50%",
    position: "absolute",
  },
  timeTypo: {
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    top: 0,
  },
  timeLayout: {
    width: 54,
    position: "absolute",
  },
  japanese1: {
    width: 102,
    color: Color.ew,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_lg,
    top: 0,
    textAlign: "left",
    left: 0,
    height: 28,
  },
  icon: {
    left: 350,
    height: 19,
    width: 19,
    top: 1,
    position: "absolute",
  },
  japanese: {
    top: 418,
    height: 28,
    left: 0,
  },
  russian1: {
    width: 74,
    color: Color.ew,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_lg,
    top: 0,
    textAlign: "left",
    left: 0,
    height: 28,
  },
  russian: {
    top: 358,
    height: 28,
    left: 0,
  },
  icon2: {
    opacity: 0.7,
    left: 350,
    height: 19,
    width: 19,
    top: 1,
    position: "absolute",
  },
  arabic: {
    top: 298,
    height: 28,
    left: 0,
  },
  french: {
    top: 238,
    height: 28,
    left: 0,
  },
  spanish: {
    top: 178,
    height: 28,
    left: 0,
  },
  hindhi: {
    top: 118,
    height: 28,
    left: 0,
  },
  urdu1: {
    width: 63,
    color: Color.ew,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_lg,
    top: 0,
    textAlign: "left",
    left: 0,
    height: 28,
  },
  urdu: {
    top: 55,
    height: 28,
    left: 0,
  },
  language: {
    width: 109,
    textAlign: "left",
    position: "absolute",
    top: 0,
    left: 0,
  },
  languages: {
    top: 315,
    height: 446,
    left: 31,
    width: 369,
  },
  englishUk1: {
    height: 38,
    color: Color.ew,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_lg,
  },
  englishUk: {
    top: 120,
    height: 38,
    left: 0,
  },
  englishUs1: {
    color: Color.ew,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_lg,
    height: 28,
  },
  icon8: {
    marginLeft: 165.5,
    height: 19,
    width: 19,
    top: 1,
    left: "50%",
  },
  englishUs: {
    top: 65,
    height: 28,
    left: 0,
  },
  suggested1: {
    height: 33,
    color: Color.colorTomato_300,
    fontSize: FontSize.size_xl,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
  },
  suggested: {
    top: 135,
    height: 158,
    left: 31,
    width: 369,
  },
  vectorIcon: {
    height: "40.08%",
    width: "5.23%",
    top: "33.33%",
    right: "94.77%",
    bottom: "26.59%",
    left: "0%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  language2: {
    left: 29,
    fontSize: FontSize.size_7xl,
    color: Color.colorGray_400,
    width: 164,
    textAlign: "left",
    position: "absolute",
  },
  language1: {
    top: 74,
    left: 26,
    width: 193,
    height: 39,
    position: "absolute",
  },
  time: {
    fontSize: FontSize.size_mini,
    letterSpacing: 0,
    lineHeight: 18,
    textAlign: "center",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    top: 0,
    color: Color.ew,
    left: 0,
  },
  action: {
    top: 14,
    left: 20,
    height: 18,
  },
  containerIcon: {
    marginTop: -5.84,
    top: "50%",
    right: 15,
    width: 67,
    height: 12,
    position: "absolute",
  },
  statusBar: {
    marginLeft: -183,
    top: 9,
    width: 375,
    height: 44,
  },
  languagePage: {
    backgroundColor: Color.iOSFFFFFF,
    flex: 1,
    width: "100%",
    height: 928,
    overflow: "hidden",
  },
});

export default LanguagePage;
