import * as React from "react";
import { Text, StyleSheet, View, Image } from "react-native";
import { Padding, FontFamily, Color, FontSize, Border } from "../GlobalStyles";

const CustomerService = () => {
  return (
    <View style={styles.customerService}>
      <View
        style={[styles.ofCourseWeWillBeWaitingParent, styles.parentSpaceBlock1]}
      >
        <Text
          style={[styles.ofCourseWe, styles.ofCourseWeTypo]}
        >{`Of course, we will be 
waiting for your offer 👍🏻`}</Text>
        <Text style={[styles.text, styles.textTypo]}>09:41</Text>
      </View>
      <View
        style={[styles.thankYouIWillMakeAnOffeParent, styles.parentSpaceBlock]}
      >
        <Text
          style={[styles.ofCourseWe, styles.ofCourseWeTypo]}
        >{`Thank you! I will make an
offer right now 😍
😍
`}</Text>
        <Text style={[styles.text1, styles.textTypo1]}>09:41</Text>
      </View>
      <View style={styles.ofCourseYouCanPleaseMakeParent}>
        <Text
          style={[styles.ofCourseWe, styles.ofCourseWeTypo]}
        >{`Of course you can, please
make an offer. If the price
is still suitable. then we will
accept 😁
😁
`}</Text>
        <Text style={[styles.text, styles.textTypo]}>09:41</Text>
      </View>
      <View style={[styles.helloGoodMorningParent, styles.parentPosition1]}>
        <Text style={styles.ofCourseWeTypo}>Hello, good morning</Text>
        <Text style={[styles.text3, styles.textTypo1]}>09:41</Text>
      </View>
      <View
        style={[styles.canIMakeAnOfferToThePriParent, styles.parentPosition]}
      >
        <Text style={[styles.ofCourseWe, styles.ofCourseWeTypo]}>
          Can I make an offer to the price? I think the current price is too
          high 😅 😅
        </Text>
        <Text style={[styles.text4, styles.textTypo1]}>09:41</Text>
      </View>
      <View
        style={[styles.hiGoodMorningIWantToBuyParent, styles.parentPosition]}
      >
        <Text style={[styles.ofCourseWe, styles.ofCourseWeTypo]}>
          Hi Good Morning, I want to buy a BMW M5 Series
        </Text>
        <Text style={[styles.text5, styles.textTypo1]}>09:41</Text>
      </View>
      <View style={styles.today}>
        <Text style={[styles.today1, styles.textTypo]}>Today</Text>
      </View>
      <View style={[styles.peopleBusService, styles.frameIconLayout]}>
        <Image
          style={[styles.vectorIcon, styles.vectorIconLayout]}
          resizeMode="cover"
          source={require("../assets/vector77.png")}
        />
        <Image
          style={[styles.frameIcon, styles.frameIconLayout]}
          resizeMode="cover"
          source={require("../assets/frame2.png")}
        />
        <Text style={[styles.peopleBusService1, styles.timeTypo]}>
          People Bus Service
        </Text>
        <Image
          style={[styles.vectorIcon1, styles.vectorIconLayout]}
          resizeMode="cover"
          source={require("../assets/vector13.png")}
        />
      </View>
      <View style={styles.statusBar}>
        <View style={[styles.action, styles.timeLayout]}>
          <Text style={[styles.time, styles.timeLayout]}>9:41</Text>
        </View>
        <Image
          style={styles.containerIcon}
          resizeMode="cover"
          source={require("../assets/container2.png")}
        />
      </View>
      <View style={[styles.message, styles.frameFlexBox]}>
        <View style={[styles.frame, styles.frameFlexBox]}>
          <Text style={[styles.message1, styles.textTypo1]}>Message...</Text>
          <Image
            style={styles.imageIcon}
            resizeMode="cover"
            source={require("../assets/image.png")}
          />
        </View>
        <Image
          style={styles.messageChild}
          resizeMode="cover"
          source={require("../assets/voice-bar.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  parentSpaceBlock1: {
    paddingTop: Padding.p_xs,
    alignItems: "flex-end",
  },
  ofCourseWeTypo: {
    textAlign: "left",
    fontFamily: FontFamily.poppinsRegular,
    color: Color.iOSFFFFFF,
    fontSize: FontSize.size_mini,
  },
  textTypo: {
    color: Color.ew,
    fontFamily: FontFamily.poppinsLight,
    fontWeight: "300",
    textAlign: "left",
  },
  parentSpaceBlock: {
    paddingVertical: Padding.p_2xs,
    alignItems: "center",
    height: 68,
  },
  textTypo1: {
    fontFamily: FontFamily.poppinsLight,
    fontWeight: "300",
    fontSize: FontSize.size_smi,
    textAlign: "left",
  },
  parentPosition1: {
    paddingHorizontal: Padding.p_xl,
    width: 284,
    left: 26,
    flexDirection: "row",
    backgroundColor: Color.ew,
    borderBottomLeftRadius: Border.br_mini,
    borderBottomRightRadius: Border.br_mini,
    borderTopRightRadius: Border.br_mini,
    position: "absolute",
  },
  parentPosition: {
    paddingHorizontal: Padding.p_lgi,
    left: 123,
    width: 283,
    borderTopLeftRadius: Border.br_mini,
    justifyContent: "flex-end",
    flexDirection: "row",
    borderBottomLeftRadius: Border.br_mini,
    borderBottomRightRadius: Border.br_mini,
    position: "absolute",
  },
  frameIconLayout: {
    height: 52,
    position: "absolute",
  },
  vectorIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  timeTypo: {
    textAlign: "center",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    lineHeight: 18,
    letterSpacing: 0,
    left: 0,
    color: Color.ew,
  },
  timeLayout: {
    width: 54,
    position: "absolute",
  },
  frameFlexBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  ofCourseWe: {
    display: "flex",
    width: 213,
    alignItems: "center",
  },
  text: {
    fontSize: FontSize.size_smi,
    color: Color.ew,
  },
  ofCourseWeWillBeWaitingParent: {
    top: 666,
    paddingBottom: Padding.p_3xs,
    paddingHorizontal: Padding.p_xl,
    width: 284,
    left: 26,
    flexDirection: "row",
    backgroundColor: Color.ew,
    borderBottomLeftRadius: Border.br_mini,
    borderBottomRightRadius: Border.br_mini,
    borderTopRightRadius: Border.br_mini,
    position: "absolute",
    justifyContent: "flex-end",
    height: 68,
    paddingTop: Padding.p_xs,
  },
  text1: {
    marginLeft: -1,
    color: Color.iOSFFFFFF,
    fontFamily: FontFamily.poppinsLight,
    fontWeight: "300",
  },
  thankYouIWillMakeAnOffeParent: {
    top: 574,
    left: 124,
    backgroundColor: Color.colorTomato_700,
    width: 283,
    borderTopLeftRadius: Border.br_mini,
    paddingVertical: Padding.p_2xs,
    paddingHorizontal: Padding.p_xl,
    justifyContent: "flex-end",
    flexDirection: "row",
    borderBottomLeftRadius: Border.br_mini,
    borderBottomRightRadius: Border.br_mini,
    position: "absolute",
  },
  ofCourseYouCanPleaseMakeParent: {
    top: 439,
    left: 27,
    width: 282,
    height: 110,
    paddingHorizontal: Padding.p_lg,
    paddingTop: Padding.p_2xs,
    paddingBottom: Padding.p_6xs,
    justifyContent: "flex-end",
    alignItems: "flex-end",
    backgroundColor: Color.ew,
    borderBottomLeftRadius: Border.br_mini,
    borderBottomRightRadius: Border.br_mini,
    borderTopRightRadius: Border.br_mini,
    flexDirection: "row",
    position: "absolute",
  },
  text3: {
    marginLeft: 61,
    color: Color.iOSFFFFFF,
    fontFamily: FontFamily.poppinsLight,
    fontWeight: "300",
  },
  helloGoodMorningParent: {
    top: 379,
    height: 48,
    paddingBottom: Padding.p_smi,
    alignItems: "center",
    paddingHorizontal: Padding.p_xl,
    width: 284,
    left: 26,
  },
  text4: {
    marginLeft: 1,
    color: Color.iOSFFFFFF,
    fontFamily: FontFamily.poppinsLight,
    fontWeight: "300",
  },
  canIMakeAnOfferToThePriParent: {
    top: 266,
    backgroundColor: Color.colorTomato_100,
    height: 90,
    paddingBottom: Padding.p_4xs,
    paddingTop: Padding.p_xs,
    alignItems: "flex-end",
  },
  text5: {
    color: Color.iOSFFFFFF,
    fontFamily: FontFamily.poppinsLight,
    fontWeight: "300",
  },
  hiGoodMorningIWantToBuyParent: {
    top: 188,
    backgroundColor: Color.colorTomato_600,
    paddingVertical: Padding.p_2xs,
    alignItems: "center",
    height: 68,
  },
  today1: {
    fontSize: FontSize.size_4xs,
  },
  today: {
    top: 140,
    left: 191,
    borderRadius: Border.br_8xs,
    backgroundColor: Color.colorWhitesmoke_200,
    width: 50,
    height: 24,
    paddingHorizontal: 0,
    paddingVertical: Padding.p_9xs,
    alignItems: "center",
    justifyContent: "flex-end",
    position: "absolute",
  },
  vectorIcon: {
    height: "30.55%",
    width: "4.28%",
    top: "35.07%",
    right: "95.72%",
    bottom: "34.38%",
    left: "0%",
  },
  frameIcon: {
    left: 286,
    width: 52,
    top: 0,
    overflow: "hidden",
  },
  peopleBusService1: {
    bottom: 18,
    fontSize: FontSize.size_6xl,
    width: 292,
    position: "absolute",
  },
  vectorIcon1: {
    height: "41.76%",
    width: "6.68%",
    top: "27.44%",
    right: "0%",
    bottom: "30.8%",
    left: "93.32%",
  },
  peopleBusService: {
    top: 71,
    left: 32,
    width: 374,
  },
  time: {
    textAlign: "center",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    lineHeight: 18,
    letterSpacing: 0,
    left: 0,
    color: Color.ew,
    top: 0,
    fontSize: FontSize.size_mini,
    width: 54,
  },
  action: {
    top: 14,
    left: 20,
    height: 18,
  },
  containerIcon: {
    marginTop: -5.84,
    top: "50%",
    right: 15,
    width: 67,
    height: 12,
    position: "absolute",
  },
  statusBar: {
    marginLeft: -183,
    top: 9,
    left: "50%",
    width: 375,
    height: 44,
    position: "absolute",
  },
  message1: {
    color: Color.colorDarkgray_100,
  },
  imageIcon: {
    width: 16,
    height: 16,
    marginLeft: 188,
  },
  frame: {
    borderRadius: Border.br_mini,
    backgroundColor: "rgba(0, 0, 0, 0.02)",
    width: 314,
    height: 55,
    paddingHorizontal: Padding.p_3xl,
    paddingVertical: Padding.p_mid,
    overflow: "hidden",
    alignItems: "center",
  },
  messageChild: {
    width: 56,
    marginLeft: 11,
    height: 56,
  },
  message: {
    top: 832,
    left: 25,
    width: 381,
    height: 56,
    alignItems: "center",
    position: "absolute",
  },
  customerService: {
    backgroundColor: Color.iOSFFFFFF,
    flex: 1,
    width: "100%",
    height: 975,
  },
});

export default CustomerService;
