const Stack = createNativeStackNavigator();
import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";

import Profile13 from "./screens/Profile13";
import Profile12 from "./screens/Profile12";
import Profile14 from "./screens/Profile14";
import Profile15 from "./screens/Profile15";
import Profile16 from "./screens/Profile16";
import Profile17 from "./screens/Profile17";
import Profile18 from "./screens/Profile18";
import Profile19 from "./screens/Profile19";
import Profile20 from "./screens/Profile20";
import Schedules from "./screens/Schedules";
import NotificationPage from "./screens/NotificationPage";
import LanguagePage from "./screens/LanguagePage";
import ProfilePage from "./screens/ProfilePage";
import ProfileEdit from "./screens/ProfileEdit";
import ProfileAddress from "./screens/ProfileAddress";
import HelpCenter from "./screens/HelpCenter";
import HelpCenter2 from "./screens/HelpCenter2";
import SecurityPage from "./screens/SecurityPage";
import PaymentPage from "./screens/PaymentPage";
import Card from "./screens/Card";
import Privacy from "./screens/Privacy";
import HelpCenterContactUs from "./screens/HelpCenterContactUs";
import CustomerService from "./screens/CustomerService";
import CustomerService2 from "./screens/CustomerService2";
import LogoutPage from "./screens/LogoutPage";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text, Pressable, TouchableOpacity } from "react-native";

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(true);

  return (
    <>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen
              name="Profile13"
              component={Profile13}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Profile12"
              component={Profile12}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Profile14"
              component={Profile14}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Profile15"
              component={Profile15}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Profile16"
              component={Profile16}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Profile17"
              component={Profile17}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Profile18"
              component={Profile18}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Profile19"
              component={Profile19}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Profile20"
              component={Profile20}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Schedules"
              component={Schedules}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="NotificationPage"
              component={NotificationPage}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="LanguagePage"
              component={LanguagePage}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ProfilePage"
              component={ProfilePage}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ProfileEdit"
              component={ProfileEdit}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ProfileAddress"
              component={ProfileAddress}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="HelpCenter"
              component={HelpCenter}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="HelpCenter2"
              component={HelpCenter2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SecurityPage"
              component={SecurityPage}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="PaymentPage"
              component={PaymentPage}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Card"
              component={Card}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Privacy"
              component={Privacy}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="HelpCenterContactUs"
              component={HelpCenterContactUs}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CustomerService"
              component={CustomerService}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CustomerService2"
              component={CustomerService2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="LogoutPage"
              component={LogoutPage}
              options={{ headerShown: false }}
            />
          </Stack.Navigator>
        ) : null}
      </NavigationContainer>
    </>
  );
};
export default App;
