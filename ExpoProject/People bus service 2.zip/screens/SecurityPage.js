import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const SecurityPage = () => {
  return (
    <View style={styles.securityPage}>
      <View style={[styles.frame, styles.frameLayout2]}>
        <View style={styles.frame1}>
          <View style={styles.statusBar}>
            <View style={[styles.action, styles.timeLayout]}>
              <Text style={[styles.time, styles.timeTypo]}>9:41</Text>
            </View>
            <Image
              style={styles.containerIcon}
              contentFit="cover"
              source={require("../assets/container.png")}
            />
          </View>
        </View>
        <View style={styles.frame2}>
          <View style={[styles.security, styles.securityPosition]}>
            <Image
              style={[styles.vectorIcon, styles.vectorIconLayout]}
              contentFit="cover"
              source={require("../assets/vector59.png")}
            />
            <Text style={[styles.security1, styles.securityPosition]}>
              Security
            </Text>
          </View>
        </View>
        <View style={[styles.frame3, styles.frameLayout1]}>
          <View style={[styles.rememberMe, styles.frameLayout1]}>
            <Image
              style={styles.button1Icon}
              contentFit="cover"
              source={require("../assets/button-7.png")}
            />
            <Text style={styles.rememberMe1}>{`Remember me `}</Text>
          </View>
        </View>
        <View style={[styles.frame4, styles.frameLayout1]}>
          <View style={[styles.rememberMe, styles.frameLayout1]}>
            <Image
              style={styles.button1Icon}
              contentFit="cover"
              source={require("../assets/button-9.png")}
            />
            <Text style={styles.rememberMe1}>Face ID</Text>
          </View>
        </View>
        <View style={[styles.frame5, styles.frameLayout1]}>
          <View style={[styles.rememberMe, styles.frameLayout1]}>
            <Image
              style={styles.button1Icon}
              contentFit="cover"
              source={require("../assets/button-7.png")}
            />
            <Text style={styles.rememberMe1}>Biometric ID</Text>
          </View>
        </View>
      </View>
      <View style={[styles.frame6, styles.frameLayout]}>
        <View style={[styles.frame7, styles.frameLayout]}>
          <View style={[styles.googleAuthenticator, styles.frameLayout1]}>
            <Image
              style={[styles.vectorIcon1, styles.vectorIconLayout]}
              contentFit="cover"
              source={require("../assets/vector60.png")}
            />
            <Text style={styles.rememberMe1}>Google Authenticator</Text>
          </View>
        </View>
        <View style={[styles.frame8, styles.framePosition]}>
          <LinearGradient
            style={[styles.button, styles.framePosition]}
            locations={[0, 1]}
            colors={["rgba(240, 0, 0, 0.96)", "#dc281e"]}
          >
            <Text style={[styles.changePassword, styles.changeTypo]}>
              Change Password
            </Text>
          </LinearGradient>
        </View>
        <View style={[styles.frame9, styles.framePosition]}>
          <LinearGradient
            style={[styles.button, styles.framePosition]}
            locations={[0, 1]}
            colors={["rgba(240, 0, 0, 0.96)", "#dc281e"]}
          >
            <Text style={[styles.changePin, styles.changeTypo]}>
              Change PIN
            </Text>
          </LinearGradient>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  frameLayout2: {
    width: 394,
    overflow: "hidden",
  },
  timeLayout: {
    width: 54,
    position: "absolute",
  },
  timeTypo: {
    textAlign: "center",
    color: Color.ew,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    lineHeight: 18,
    letterSpacing: 0,
  },
  securityPosition: {
    width: 202,
    left: 0,
    position: "absolute",
  },
  vectorIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  frameLayout1: {
    height: 27,
    position: "absolute",
  },
  frameLayout: {
    width: 364,
    overflow: "hidden",
  },
  framePosition: {
    height: 54,
    left: 0,
    position: "absolute",
  },
  changeTypo: {
    color: Color.iOSFFFFFF,
    fontSize: FontSize.iOSDefaultBody_size,
    marginTop: -14,
    textAlign: "left",
    top: "50%",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    left: "50%",
    position: "absolute",
  },
  time: {
    fontSize: FontSize.size_mini,
    left: 0,
    width: 54,
    position: "absolute",
    top: 0,
  },
  action: {
    top: 14,
    left: 20,
    height: 18,
  },
  containerIcon: {
    marginTop: -5.84,
    right: 15,
    width: 67,
    height: 12,
    top: "50%",
    position: "absolute",
  },
  statusBar: {
    marginLeft: -183,
    width: 375,
    left: "50%",
    height: 44,
    top: 0,
    position: "absolute",
  },
  frame1: {
    left: 5,
    width: 384,
    height: 44,
    top: 0,
    overflow: "hidden",
    position: "absolute",
  },
  vectorIcon: {
    height: "84.33%",
    width: "7.92%",
    top: "13.53%",
    right: "90.1%",
    bottom: "2.14%",
    left: "1.98%",
  },
  security1: {
    bottom: 0,
    fontSize: FontSize.size_6xl,
    textAlign: "center",
    color: Color.ew,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    lineHeight: 18,
    letterSpacing: 0,
  },
  security: {
    height: 18,
    top: 0,
  },
  frame2: {
    top: 73,
    left: 11,
    width: 372,
    height: 18,
    overflow: "hidden",
    position: "absolute",
  },
  button1Icon: {
    top: 2,
    left: 329,
    borderRadius: Border.br_mini,
    width: 44,
    height: 24,
    position: "absolute",
  },
  rememberMe1: {
    fontSize: FontSize.size_lg,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    textAlign: "left",
    color: Color.ew,
    letterSpacing: 0,
    left: 0,
    top: 0,
    position: "absolute",
  },
  rememberMe: {
    left: 21,
    width: 373,
    top: 0,
  },
  frame3: {
    top: 143,
    left: 0,
    overflow: "hidden",
    width: 394,
  },
  frame4: {
    top: 204,
    left: 0,
    overflow: "hidden",
    width: 394,
  },
  frame5: {
    top: 266,
    left: 0,
    overflow: "hidden",
    width: 394,
  },
  frame: {
    top: 9,
    left: 17,
    height: 293,
    overflow: "hidden",
    position: "absolute",
  },
  vectorIcon1: {
    height: "57.88%",
    width: "2.84%",
    top: "22.36%",
    right: "0.03%",
    bottom: "19.75%",
    left: "97.13%",
  },
  googleAuthenticator: {
    left: 6,
    width: 358,
    top: 0,
  },
  frame7: {
    height: 27,
    position: "absolute",
    left: 0,
    top: 0,
  },
  changePassword: {
    marginLeft: -83.5,
    width: 166,
  },
  button: {
    borderRadius: Border.br_17xl,
    width: 359,
    backgroundColor: "transparent",
    top: 0,
  },
  frame8: {
    top: 166,
    width: 364,
    overflow: "hidden",
  },
  changePin: {
    marginLeft: -54.5,
    width: 101,
  },
  frame9: {
    top: 86,
    width: 364,
    overflow: "hidden",
  },
  frame6: {
    top: 343,
    left: 32,
    height: 220,
    position: "absolute",
  },
  securityPage: {
    backgroundColor: Color.iOSFFFFFF,
    flex: 1,
    width: "100%",
    height: 925,
  },
});

export default SecurityPage;
