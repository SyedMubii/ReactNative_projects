import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const Profile19 = () => {
  return (
    <View style={styles.profile19}>
      <View style={styles.dealsSection}>
        <View style={styles.g5}>
          <Text
            style={styles.iJustBought}
          >{`I just bought it, and it arrived at my house in just 3 days. `}</Text>
          <View style={[styles.button2, styles.buttonLayout2]}>
            <Image
              style={[styles.vectorIcon, styles.vectorIconLayout]}
              contentFit="cover"
              source={require("../assets/vector24.png")}
            />
            <Text style={[styles.text, styles.textFlexBox]}>5</Text>
          </View>
          <Text style={[styles.janeCooper, styles.janeLayout]}>
            Jane Cooper
          </Text>
          <Image
            style={[styles.g5Child, styles.childLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-315.png")}
          />
        </View>
        <View style={[styles.g4, styles.g4Layout]}>
          <Text style={[styles.iJustBought1, styles.theBusIsLayout]}>
            I just bought it, and it arrived at my house in just 3 days. Wow, I
            don’t think there;s anything faster
          </Text>
          <View style={[styles.button21, styles.buttonLayout2]}>
            <Image
              style={[styles.vectorIcon, styles.vectorIconLayout]}
              contentFit="cover"
              source={require("../assets/vector24.png")}
            />
            <Text style={[styles.text, styles.textFlexBox]}>5</Text>
          </View>
          <Text style={[styles.janeCooper1, styles.janeLayout]}>
            Jane Cooper
          </Text>
          <Image
            style={styles.g4Child}
            contentFit="cover"
            source={require("../assets/ellipse-315.png")}
          />
          <View style={[styles.vectorParent, styles.vectorLayout]}>
            <Image
              style={[styles.vectorIcon2, styles.vectorIconPosition1]}
              contentFit="cover"
              source={require("../assets/vector25.png")}
            />
            <Text style={[styles.text2, styles.text2Typo]}>729</Text>
            <Text style={[styles.daysAgo, styles.allPosition]}>6 days ago</Text>
          </View>
        </View>
        <View style={[styles.g3, styles.g4Layout]}>
          <Text style={[styles.theBusIs, styles.theBusIsLayout]}>
            The bus is awesome and very fast, my family and I really like it,
            wow!! Highly recommended 👍🏻 👍🏻
          </Text>
          <View style={styles.button22}>
            <Image
              style={[styles.vectorIcon, styles.vectorIconLayout]}
              contentFit="cover"
              source={require("../assets/vector26.png")}
            />
            <Text style={[styles.text, styles.textFlexBox]}>5</Text>
          </View>
          <Text style={[styles.lenaRose, styles.janeLayout]}>Lena Rose</Text>
          <Image
            style={[styles.g3Child, styles.childLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-315.png")}
          />
          <View style={[styles.vectorGroup, styles.vectorLayout]}>
            <Image
              style={[styles.vectorIcon2, styles.vectorIconPosition1]}
              contentFit="cover"
              source={require("../assets/vector25.png")}
            />
            <Text style={[styles.text2, styles.text2Typo]}>729</Text>
            <Text style={[styles.daysAgo, styles.allPosition]}>6 days ago</Text>
          </View>
        </View>
        <View style={[styles.g2, styles.g4Layout]}>
          <Text style={[styles.iJustBought1, styles.theBusIsLayout]}>
            I just bought it, and it arrived at my house in just 3 days. Wow, I
            don’t think there;s anything faster
          </Text>
          <View style={[styles.vectorContainer, styles.vectorLayout]}>
            <Image
              style={[styles.vectorIcon2, styles.vectorIconPosition1]}
              contentFit="cover"
              source={require("../assets/vector25.png")}
            />
            <Text style={[styles.text2, styles.text2Typo]}>729</Text>
            <Text style={[styles.daysAgo, styles.allPosition]}>6 days ago</Text>
          </View>
          <View style={[styles.button21, styles.buttonLayout2]}>
            <Image
              style={[styles.vectorIcon, styles.vectorIconLayout]}
              contentFit="cover"
              source={require("../assets/vector24.png")}
            />
            <Text style={[styles.text, styles.textFlexBox]}>5</Text>
          </View>
          <Text style={[styles.janeCooper1, styles.janeLayout]}>
            Jane Cooper
          </Text>
          <Image
            style={styles.g4Child}
            contentFit="cover"
            source={require("../assets/ellipse-315.png")}
          />
        </View>
        <View style={[styles.g1, styles.g4Layout]}>
          <View style={[styles.vectorGroup, styles.vectorLayout]}>
            <Image
              style={[styles.vectorIcon2, styles.vectorIconPosition1]}
              contentFit="cover"
              source={require("../assets/vector25.png")}
            />
            <Text style={[styles.text2, styles.text2Typo]}>729</Text>
            <Text style={[styles.daysAgo, styles.allPosition]}>6 days ago</Text>
          </View>
          <Text style={[styles.theBusIs, styles.theBusIsLayout]}>
            The bus is awesome and very fast, my family and I really like it,
            wow!! 💯💯💯
          </Text>
          <View style={styles.button22}>
            <Image
              style={[styles.vectorIcon, styles.vectorIconLayout]}
              contentFit="cover"
              source={require("../assets/vector26.png")}
            />
            <Text style={[styles.text, styles.textFlexBox]}>5</Text>
          </View>
          <Text style={[styles.lenaRose, styles.janeLayout]}>Lena Rose</Text>
          <Image
            style={[styles.g3Child, styles.childLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-315.png")}
          />
        </View>
      </View>
      <View style={[styles.button1, styles.buttonLayout1]}>
        <Text style={[styles.all, styles.allFlexBox]}>All</Text>
        <Image
          style={[styles.vectorIcon9, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector27.png")}
        />
      </View>
      <View style={[styles.button25, styles.buttonLayout]}>
        <Image
          style={[styles.vectorIcon, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector28.png")}
        />
        <Text style={[styles.text9, styles.textLayout1]}>5</Text>
      </View>
      <View style={[styles.button3, styles.buttonLayout]}>
        <Text style={[styles.text10, styles.textLayout]}>4</Text>
        <Image
          style={[styles.vectorIcon11, styles.vectorIconPosition]}
          contentFit="cover"
          source={require("../assets/vector28.png")}
        />
      </View>
      <View style={[styles.button4, styles.buttonLayout1]}>
        <Image
          style={[styles.vectorIcon, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector29.png")}
        />
        <Text style={[styles.text11, styles.textLayout1]}>3</Text>
      </View>
      <View style={[styles.button5, styles.buttonLayout1]}>
        <Text style={[styles.text12, styles.textLayout]}>2</Text>
        <Image
          style={[styles.vectorIcon13, styles.vectorIconPosition]}
          contentFit="cover"
          source={require("../assets/vector30.png")}
        />
      </View>
      <View style={styles.profileIcons}>
        <Image
          style={styles.frameIcon}
          contentFit="cover"
          source={require("../assets/frame.png")}
        />
        <Text style={[styles.reviews, styles.timeTypo]}>4.8 (86 reviews)</Text>
        <Image
          style={[styles.vectorIcon14, styles.vectorIconPosition1]}
          contentFit="cover"
          source={require("../assets/vector31.png")}
        />
      </View>
      <View style={styles.statusBar}>
        <View style={[styles.action, styles.timeLayout]}>
          <Text style={[styles.time, styles.timeLayout]}>9:41</Text>
        </View>
        <Image
          style={styles.containerIcon}
          contentFit="cover"
          source={require("../assets/container2.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  buttonLayout2: {
    height: 32,
    width: 60,
    borderWidth: 2,
    borderColor: Color.ew,
    borderStyle: "solid",
    borderRadius: Border.br_xl,
    left: 284,
    position: "absolute",
  },
  vectorIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "34.21%",
    top: "34.21%",
    height: "31.58%",
    overflow: "hidden",
    position: "absolute",
  },
  textFlexBox: {
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    position: "absolute",
  },
  janeLayout: {
    height: 25,
    width: 145,
    color: Color.colorGray_500,
    lineHeight: 30,
    fontSize: FontSize.size_mini,
    textAlign: "left",
    fontFamily: FontFamily.poppinsRegular,
    position: "absolute",
  },
  childLayout: {
    height: 48,
    width: 48,
    left: 0,
    position: "absolute",
  },
  g4Layout: {
    height: 152,
    borderRadius: Border.br_xl,
    left: 0,
    width: 378,
    position: "absolute",
    backgroundColor: Color.iOSFFFFFF,
  },
  theBusIsLayout: {
    height: 53,
    width: 372,
    textAlign: "left",
    color: Color.colorDimgray_200,
    fontFamily: FontFamily.poppinsRegular,
    lineHeight: 20,
    fontSize: FontSize.size_smi,
    left: 1,
    position: "absolute",
  },
  vectorLayout: {
    height: 19,
    width: 142,
    position: "absolute",
  },
  vectorIconPosition1: {
    left: "0%",
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    position: "absolute",
  },
  text2Typo: {
    fontSize: FontSize.size_xs,
    alignItems: "center",
    display: "flex",
    color: Color.ew,
    textAlign: "left",
  },
  allPosition: {
    top: 10,
    fontFamily: FontFamily.poppinsRegular,
    position: "absolute",
  },
  buttonLayout1: {
    height: 38,
    top: 140,
    borderRadius: Border.br_xl,
    position: "absolute",
  },
  allFlexBox: {
    textAlign: "center",
    lineHeight: 18,
  },
  buttonLayout: {
    width: 74,
    height: 38,
    top: 140,
    borderWidth: 2,
    borderColor: Color.ew,
    borderStyle: "solid",
    borderRadius: Border.br_xl,
    position: "absolute",
  },
  textLayout1: {
    width: 10,
    top: 5,
    height: 25,
    lineHeight: 30,
    fontSize: FontSize.size_mini,
    color: Color.ew,
    textAlign: "left",
    fontFamily: FontFamily.poppinsRegular,
    position: "absolute",
  },
  textLayout: {
    height: 23,
    width: 10,
    top: 3,
    lineHeight: 30,
    fontSize: FontSize.size_mini,
    color: Color.ew,
    textAlign: "left",
    fontFamily: FontFamily.poppinsRegular,
    position: "absolute",
  },
  vectorIconPosition: {
    bottom: "39.47%",
    top: "28.95%",
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    height: "31.58%",
    position: "absolute",
  },
  timeTypo: {
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    top: 0,
  },
  timeLayout: {
    width: 54,
    position: "absolute",
  },
  iJustBought: {
    top: 61,
    height: 22,
    width: 372,
    textAlign: "left",
    color: Color.colorDimgray_200,
    lineHeight: 20,
    fontSize: FontSize.size_smi,
    fontFamily: FontFamily.poppinsRegular,
    left: 1,
    position: "absolute",
  },
  vectorIcon: {
    right: "54.05%",
    left: "29.73%",
    width: "16.22%",
  },
  text: {
    top: 16,
    left: 35,
    fontSize: FontSize.size_sm,
    width: 8,
    color: Color.ew,
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.poppinsRegular,
  },
  button2: {
    top: 9,
  },
  janeCooper: {
    top: 11,
    left: 63,
    width: 145,
    color: Color.colorGray_500,
    lineHeight: 30,
  },
  g5Child: {
    top: 0,
  },
  g5: {
    top: 652,
    width: 373,
    height: 83,
    left: 0,
    position: "absolute",
  },
  iJustBought1: {
    top: 64,
  },
  button21: {
    top: 12,
  },
  janeCooper1: {
    top: 14,
    left: 63,
    width: 145,
    color: Color.colorGray_500,
    lineHeight: 30,
  },
  g4Child: {
    top: 3,
    height: 48,
    width: 48,
    left: 0,
    position: "absolute",
  },
  vectorIcon2: {
    height: "100%",
    width: "14.79%",
    top: "0%",
    right: "85.21%",
    bottom: "0%",
  },
  text2: {
    top: 4,
    left: 30,
    width: 22,
    height: 11,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  daysAgo: {
    left: 72,
    width: 70,
    fontSize: FontSize.size_xs,
    alignItems: "center",
    display: "flex",
    color: Color.ew,
    textAlign: "left",
  },
  vectorParent: {
    left: 2,
    width: 142,
    top: 120,
  },
  g4: {
    top: 489,
  },
  theBusIs: {
    top: 73,
  },
  button22: {
    top: 21,
    height: 31,
    width: 60,
    borderRadius: Border.br_xl,
    left: 284,
    borderWidth: 2,
    borderColor: Color.ew,
    borderStyle: "solid",
    position: "absolute",
  },
  lenaRose: {
    top: 23,
    left: 65,
  },
  g3Child: {
    top: 13,
  },
  vectorGroup: {
    top: 127,
    left: 2,
    width: 142,
  },
  g3: {
    top: 320,
  },
  vectorContainer: {
    top: 120,
    width: 142,
    left: 1,
  },
  g2: {
    top: 169,
  },
  g1: {
    top: 0,
  },
  dealsSection: {
    top: 189,
    height: 735,
    width: 378,
    left: 24,
    position: "absolute",
  },
  all: {
    fontSize: FontSize.iOSMediumBody_size,
    color: Color.iOSFFFFFF,
    left: 44,
    top: 10,
    fontFamily: FontFamily.poppinsRegular,
    position: "absolute",
  },
  vectorIcon9: {
    width: "14.46%",
    right: "59.04%",
    left: "26.51%",
  },
  button1: {
    backgroundColor: "#272727",
    width: 83,
    height: 38,
    top: 140,
    left: 24,
  },
  text9: {
    left: 45,
  },
  button25: {
    left: 119,
  },
  text10: {
    left: 41,
  },
  vectorIcon11: {
    right: "56.76%",
    left: "27.03%",
    width: "16.22%",
  },
  button3: {
    left: 205,
  },
  text11: {
    left: 44,
  },
  button4: {
    left: 291,
    width: 73,
    borderWidth: 2,
    borderColor: Color.ew,
    borderStyle: "solid",
    height: 38,
    top: 140,
  },
  text12: {
    left: 42,
  },
  vectorIcon13: {
    width: "16.23%",
    right: "56.72%",
    left: "27.05%",
  },
  button5: {
    left: 376,
    width: 75,
    borderWidth: 2,
    borderColor: Color.ew,
    borderStyle: "solid",
    height: 38,
    top: 140,
  },
  frameIcon: {
    top: 2,
    left: 350,
    width: 33,
    height: 33,
    overflow: "hidden",
    position: "absolute",
  },
  reviews: {
    fontSize: FontSize.iOSDefaultTitle2_size,
    color: Color.colorGray_400,
    width: 202,
    left: 41,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    position: "absolute",
  },
  vectorIcon14: {
    height: "61.12%",
    width: "5.71%",
    top: "17.9%",
    right: "94.29%",
    bottom: "20.98%",
  },
  profileIcons: {
    top: 76,
    left: 26,
    width: 383,
    height: 35,
    position: "absolute",
  },
  time: {
    letterSpacing: 0,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    top: 0,
    textAlign: "center",
    lineHeight: 18,
    fontSize: FontSize.size_mini,
    width: 54,
    color: Color.ew,
    left: 0,
  },
  action: {
    left: 20,
    height: 18,
    top: 14,
  },
  containerIcon: {
    marginTop: -5.84,
    top: "50%",
    right: 15,
    width: 67,
    height: 12,
    position: "absolute",
  },
  statusBar: {
    marginLeft: -183,
    left: "50%",
    width: 375,
    height: 44,
    top: 9,
    position: "absolute",
  },
  profile19: {
    flex: 1,
    width: "100%",
    height: 929,
    opacity: 0.8,
    backgroundColor: Color.iOSFFFFFF,
  },
});

export default Profile19;
