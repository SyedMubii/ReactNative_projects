import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Border, Color, FontFamily, Padding, FontSize } from "../GlobalStyles";

const HelpCenter2 = () => {
  return (
    <View style={styles.helpCenter2}>
      <View
        style={[styles.keyboardsiosAlphbeticKeyboa, styles.statusBarPosition]}
      >
        <View style={[styles.componentSuggestionBar, styles.componentFlexBox1]}>
          <View style={styles.componentItemFlexBox}>
            <Text style={styles.text} numberOfLines={1}>
              Suggest
            </Text>
          </View>
          <Image
            style={styles.seperatorIcon}
            contentFit="cover"
            source={require("../assets/seperator.png")}
          />
          <View
            style={[
              styles.componentSuggestionItem1,
              styles.componentItemFlexBox,
            ]}
          >
            <Text style={styles.text} numberOfLines={1}>
              Suggest
            </Text>
          </View>
          <Image
            style={styles.seperatorIcon}
            contentFit="cover"
            source={require("../assets/seperator1.png")}
          />
          <View
            style={[
              styles.componentSuggestionItem1,
              styles.componentItemFlexBox,
            ]}
          >
            <Text style={styles.text} numberOfLines={1}>
              Suggest
            </Text>
          </View>
        </View>
        <View style={styles.iosAlphbeticKeyboardEngli}>
          <View
            style={[styles.componentSuggestionBar, styles.componentFlexBox1]}
          >
            <View style={styles.componentItemFlexBox}>
              <Text style={styles.text} numberOfLines={1}>
                Suggest
              </Text>
            </View>
            <Image
              style={styles.seperatorIcon}
              contentFit="cover"
              source={require("../assets/seperator.png")}
            />
            <View
              style={[
                styles.componentSuggestionItem1,
                styles.componentItemFlexBox,
              ]}
            >
              <Text style={styles.text} numberOfLines={1}>
                Suggest
              </Text>
            </View>
            <Image
              style={styles.seperatorIcon}
              contentFit="cover"
              source={require("../assets/seperator1.png")}
            />
            <View
              style={[
                styles.componentSuggestionItem1,
                styles.componentItemFlexBox,
              ]}
            >
              <Text style={styles.text} numberOfLines={1}>
                Suggest
              </Text>
            </View>
          </View>
          <View style={[styles.keysLayoutAlphabeticEng, styles.componentBg]}>
            <View style={styles.rowAlphabetic}>
              <View style={styles.componentShadowBox3}>
                <Text style={[styles.text6, styles.textTypo]}>q</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>w</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>e</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>r</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>t</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>y</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>u</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>i</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>o</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>p</Text>
              </View>
            </View>
            <View style={[styles.rowAlphabetic1, styles.rowFlexBox]}>
              <View style={styles.componentShadowBox3}>
                <Text style={[styles.text6, styles.textTypo]}>a</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>s</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>d</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>f</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>g</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>h</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>j</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>k</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>l</Text>
              </View>
            </View>
            <View style={styles.rowFlexBox}>
              <View style={[styles.componentKey19, styles.componentShadowBox1]}>
                <Text style={[styles.text25, styles.spaceTypo]}>􀆝</Text>
              </View>
              <View
                style={[styles.rowAlphabetic2, styles.rowAlphabetic2SpaceBlock]}
              >
                <View style={styles.componentShadowBox3}>
                  <Text style={[styles.text6, styles.textTypo]}>z</Text>
                </View>
                <View style={styles.componentShadowBox2}>
                  <Text style={[styles.text6, styles.textTypo]}>x</Text>
                </View>
                <View style={styles.componentShadowBox2}>
                  <Text style={[styles.text6, styles.textTypo]}>c</Text>
                </View>
                <View style={styles.componentShadowBox2}>
                  <Text style={[styles.text6, styles.textTypo]}>v</Text>
                </View>
                <View style={styles.componentShadowBox2}>
                  <Text style={[styles.text6, styles.textTypo]}>b</Text>
                </View>
                <View style={styles.componentShadowBox2}>
                  <Text style={[styles.text6, styles.textTypo]}>n</Text>
                </View>
                <View style={styles.componentShadowBox2}>
                  <Text style={[styles.text6, styles.textTypo]}>m</Text>
                </View>
              </View>
              <View style={[styles.componentKey27, styles.componentFlexBox]}>
                <Text style={[styles.text25, styles.spaceTypo]}>􀆛</Text>
              </View>
            </View>
            <View style={styles.rowFlexBox}>
              <View style={[styles.componentKey28, styles.componentFlexBox]}>
                <Text style={[styles.text25, styles.spaceTypo]}>123</Text>
              </View>
              <View style={[styles.componentKey29, styles.componentShadowBox]}>
                <Text style={styles.spaceTypo}>space</Text>
              </View>
              <View style={[styles.componentKey30, styles.componentShadowBox]}>
                <Text style={[styles.text25, styles.spaceTypo]}>Go</Text>
              </View>
            </View>
          </View>
          <View style={[styles.componentHomeIndicatorSec, styles.componentBg]}>
            <View style={styles.keys}>
              <View style={styles.componentKey31}>
                <Text style={[styles.text36, styles.textTypo]}>􀎸</Text>
              </View>
              <View style={styles.componentKey31}>
                <Text style={[styles.text36, styles.textTypo]}>􀊰</Text>
              </View>
            </View>
            <View
              style={[styles.componentHomeIndicator, styles.componentFlexBox1]}
            >
              <View style={styles.indicator} />
            </View>
          </View>
        </View>
      </View>
      <View style={[styles.peopleBusService, styles.frameIconLayout]}>
        <Image
          style={[styles.vectorIcon, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector53.png")}
        />
        <Image
          style={[styles.frameIcon, styles.frameIconLayout]}
          contentFit="cover"
          source={require("../assets/frame1.png")}
        />
        <Text style={styles.helpCenter}>Help Center</Text>
        <Image
          style={[styles.vectorIcon1, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector54.png")}
        />
      </View>
      <View style={styles.searchBar}>
        <View style={styles.view}>
          <Text style={[styles.howToUse, styles.faqTypo]}>
            How to use Carea ?
          </Text>
        </View>
        <View style={[styles.view1, styles.view1Layout]}>
          <Image
            style={styles.vectorIcon2}
            contentFit="cover"
            source={require("../assets/vector58.png")}
          />
          <Text style={[styles.whyDidMy, styles.whyTypo]}>
            Why did my payment did’nt working?
          </Text>
          <Text style={[styles.whyAreThe, styles.whyTypo]}>
            Why are the my shipping prices different ?
          </Text>
          <Text style={[styles.whyICant, styles.whyTypo]}>
            Why I can’t add a new payment method ?
          </Text>
          <Text style={[styles.whyDidntI, styles.whyTypo]}>
            Why didn’t I get the e-receipt after payment ?
          </Text>
          <View style={[styles.child, styles.itemLayout]} />
          <View style={[styles.item, styles.itemLayout]} />
          <View style={[styles.inner, styles.itemLayout]} />
          <View style={[styles.lineView, styles.itemLayout]} />
        </View>
        <View style={[styles.search, styles.view1Layout]}>
          <Text style={[styles.whyI, styles.whyTypo]}>Why I</Text>
          <Image
            style={[styles.vectorIcon3, styles.vectorIconLayout]}
            contentFit="cover"
            source={require("../assets/vector57.png")}
          />
          <Image
            style={styles.vectorIcon4}
            contentFit="cover"
            source={require("../assets/vector35.png")}
          />
        </View>
      </View>
      <View style={styles.faqButton}>
        <View style={styles.button4}>
          <Text style={[styles.text38, styles.text38Typo]}>Payme</Text>
        </View>
        <View style={[styles.button3, styles.buttonBorder]}>
          <Text style={styles.service}>Service</Text>
        </View>
        <View style={[styles.button2, styles.buttonBorder]}>
          <Text style={[styles.account, styles.text38Typo]}>Account</Text>
        </View>
        <View style={[styles.button1, styles.button1Layout]}>
          <Text style={styles.general}>General</Text>
        </View>
        <View style={[styles.faqButtonChild, styles.faqPosition]} />
        <Text style={[styles.contactUs, styles.button1Layout]}>Contact us</Text>
        <View style={[styles.faqButtonItem, styles.faqPosition]} />
        <Text style={[styles.faq, styles.faqTypo]}>FAQ</Text>
      </View>
      <View style={[styles.statusBar, styles.statusBarPosition]}>
        <View style={[styles.action, styles.timeLayout]}>
          <Text style={[styles.time, styles.timeLayout]}>9:41</Text>
        </View>
        <Image
          style={styles.containerIcon}
          contentFit="cover"
          source={require("../assets/container2.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  statusBarPosition: {
    left: "50%",
    position: "absolute",
  },
  componentFlexBox1: {
    justifyContent: "center",
    alignItems: "center",
  },
  componentItemFlexBox: {
    height: 34,
    borderRadius: Border.br_8xs_6,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    flex: 1,
  },
  componentBg: {
    backgroundColor: Color.iOSAlfaCCCED376,
    alignSelf: "stretch",
  },
  textTypo: {
    fontFamily: FontFamily.iOSDefaultTitle2,
    textAlign: "center",
  },
  rowFlexBox: {
    marginTop: 12,
    flexDirection: "row",
    alignSelf: "stretch",
  },
  componentShadowBox1: {
    padding: Padding.p_2xs,
    height: 42,
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "#898a8d",
    borderRadius: Border.br_8xs_6,
    overflow: "hidden",
  },
  spaceTypo: {
    lineHeight: 21,
    fontSize: FontSize.iOSMediumBody_size,
    color: Color.ew,
    textAlign: "center",
    fontFamily: FontFamily.iOSMediumBody,
    flex: 1,
  },
  rowAlphabetic2SpaceBlock: {
    marginLeft: 1,
    flexDirection: "row",
  },
  componentFlexBox: {
    backgroundColor: Color.iOSADB3BC,
    justifyContent: "center",
    alignItems: "center",
  },
  componentShadowBox: {
    marginLeft: 6,
    padding: Padding.p_2xs,
    height: 42,
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "#898a8d",
    borderRadius: Border.br_8xs_6,
    flexDirection: "row",
    overflow: "hidden",
  },
  frameIconLayout: {
    height: 52,
    position: "absolute",
  },
  vectorIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  faqTypo: {
    display: "flex",
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
  },
  view1Layout: {
    width: 380,
    borderRadius: Border.br_3xs,
    left: 0,
    position: "absolute",
  },
  whyTypo: {
    height: 14,
    display: "flex",
    textAlign: "left",
    color: Color.iOSFFFFFF,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    alignItems: "center",
    position: "absolute",
  },
  itemLayout: {
    width: 340,
    borderTopWidth: 2,
    borderColor: Color.iOSFFFFFF,
    borderStyle: "solid",
    left: 18,
    height: 2,
    position: "absolute",
  },
  text38Typo: {
    height: 25,
    fontFamily: FontFamily.poppinsRegular,
    lineHeight: 30,
    fontSize: FontSize.size_mini,
    textAlign: "left",
    color: Color.ew,
  },
  buttonBorder: {
    paddingHorizontal: 0,
    borderRadius: Border.br_xl,
    height: 38,
    borderWidth: 2,
    borderColor: Color.ew,
    top: 62,
    borderStyle: "solid",
    alignItems: "center",
    position: "absolute",
  },
  button1Layout: {
    width: 100,
    alignItems: "center",
    position: "absolute",
  },
  faqPosition: {
    top: 34,
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  timeLayout: {
    width: 54,
    position: "absolute",
  },
  text: {
    lineHeight: 20,
    color: Color.iOS3A3B3D,
    height: 20,
    textAlign: "center",
    fontFamily: FontFamily.iOSMediumBody,
    fontSize: FontSize.iOSDefaultBody_size,
    overflow: "hidden",
    flex: 1,
  },
  seperatorIcon: {
    width: 0,
    height: 24,
    marginLeft: 2,
  },
  componentSuggestionItem1: {
    marginLeft: 2,
  },
  componentSuggestionBar: {
    paddingHorizontal: Padding.p_12xs,
    paddingTop: Padding.p_3xs,
    display: "none",
    flexDirection: "row",
    overflow: "hidden",
    backgroundColor: Color.iOSAlfaCCCED376,
    alignSelf: "stretch",
  },
  text6: {
    fontSize: FontSize.iOSDefaultTitle2_size,
    lineHeight: 28,
    color: Color.ew,
    flex: 1,
  },
  componentShadowBox3: {
    padding: Padding.p_6xs,
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "#898a8d",
    borderRadius: Border.br_8xs_6,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    overflow: "hidden",
    flex: 1,
    backgroundColor: Color.iOSFFFFFF,
  },
  componentShadowBox2: {
    marginLeft: 5,
    padding: Padding.p_6xs,
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "#898a8d",
    borderRadius: Border.br_8xs_6,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    overflow: "hidden",
    flex: 1,
    backgroundColor: Color.iOSFFFFFF,
  },
  rowAlphabetic: {
    flexDirection: "row",
    alignSelf: "stretch",
  },
  rowAlphabetic1: {
    paddingVertical: 0,
    paddingHorizontal: Padding.p_lg,
    marginTop: 12,
  },
  text25: {
    height: 20,
  },
  componentKey19: {
    width: 42,
    padding: Padding.p_2xs,
    height: 42,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    backgroundColor: Color.iOSFFFFFF,
  },
  rowAlphabetic2: {
    paddingHorizontal: Padding.p_smi,
    paddingVertical: 0,
    flex: 1,
  },
  componentKey27: {
    marginLeft: 1,
    flexDirection: "row",
    padding: Padding.p_2xs,
    height: 42,
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "#898a8d",
    borderRadius: Border.br_8xs_6,
    overflow: "hidden",
    width: 42,
  },
  componentKey28: {
    width: 87,
    padding: Padding.p_2xs,
    height: 42,
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "#898a8d",
    borderRadius: Border.br_8xs_6,
    overflow: "hidden",
    flexDirection: "row",
  },
  componentKey29: {
    flex: 1,
    backgroundColor: Color.iOSFFFFFF,
  },
  componentKey30: {
    width: 88,
    backgroundColor: Color.iOSADB3BC,
    justifyContent: "center",
    alignItems: "center",
  },
  keysLayoutAlphabeticEng: {
    paddingHorizontal: Padding.p_10xs,
    paddingVertical: Padding.p_5xs,
  },
  text36: {
    fontSize: FontSize.size_7xl,
    color: Color.iOS50555C,
  },
  componentKey31: {
    width: 47,
    height: 47,
    padding: Padding.p_5xs,
    borderRadius: Border.br_8xs_6,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    overflow: "hidden",
  },
  keys: {
    justifyContent: "space-between",
    paddingHorizontal: Padding.p_xl,
    paddingTop: Padding.p_4xs,
    flexDirection: "row",
    alignSelf: "stretch",
  },
  indicator: {
    borderRadius: Border.br_8xs,
    width: 134,
    height: 5,
    backgroundColor: Color.ew,
  },
  componentHomeIndicator: {
    paddingHorizontal: Padding.p_101xl,
    paddingTop: Padding.p_12xs,
    paddingBottom: Padding.p_4xs,
    alignSelf: "stretch",
  },
  componentHomeIndicatorSec: {
    justifyContent: "flex-end",
  },
  iosAlphbeticKeyboardEngli: {
    width: 428,
  },
  keyboardsiosAlphbeticKeyboa: {
    marginLeft: -214,
    bottom: 0,
    width: 428,
  },
  vectorIcon: {
    height: "30.55%",
    width: "4.27%",
    top: "42.71%",
    right: "95.65%",
    bottom: "26.74%",
    left: "0.08%",
  },
  frameIcon: {
    left: 286,
    width: 52,
    top: 0,
    overflow: "hidden",
  },
  helpCenter: {
    bottom: 14,
    fontSize: FontSize.size_6xl,
    width: 229,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    letterSpacing: 0,
    left: 0,
    lineHeight: 18,
    color: Color.ew,
    textAlign: "center",
    position: "absolute",
  },
  vectorIcon1: {
    height: "41.76%",
    width: "6.68%",
    top: "27.44%",
    right: "0%",
    bottom: "30.8%",
    left: "93.32%",
  },
  peopleBusService: {
    top: 67,
    left: 32,
    width: 378,
  },
  howToUse: {
    fontSize: FontSize.size_lg,
    width: 177,
    color: Color.iOSFFFFFF,
    height: 49,
    textAlign: "left",
    alignItems: "center",
  },
  view: {
    top: 313,
    paddingBottom: Padding.p_base,
    height: 49,
    backgroundColor: Color.colorTomato_500,
    borderRadius: Border.br_3xs,
    width: 381,
    left: 0,
    paddingHorizontal: Padding.p_lg,
    flexDirection: "row",
    position: "absolute",
  },
  vectorIcon2: {
    top: 243,
    left: 326,
    width: 14,
    height: 11,
    position: "absolute",
  },
  whyDidMy: {
    top: 25,
    width: 278,
    fontSize: FontSize.size_sm,
    left: 19,
    height: 14,
  },
  whyAreThe: {
    top: 77,
    width: 317,
    fontSize: FontSize.size_sm,
    left: 19,
    height: 14,
  },
  whyICant: {
    top: 129,
    width: 308,
    fontSize: FontSize.size_sm,
    left: 19,
    height: 14,
  },
  whyDidntI: {
    top: 181,
    width: 338,
    fontSize: FontSize.size_sm,
    left: 19,
    height: 14,
  },
  child: {
    top: 210,
    height: 2,
  },
  item: {
    top: 162,
    height: 2,
  },
  inner: {
    top: 109,
    height: 2,
  },
  lineView: {
    top: 57,
    height: 2,
  },
  view1: {
    top: 92,
    height: 216,
    backgroundColor: Color.colorTomato_500,
  },
  whyI: {
    top: 21,
    left: 52,
    fontSize: FontSize.size_smi,
    width: 91,
  },
  vectorIcon3: {
    height: "37.53%",
    width: "5.53%",
    top: "34.13%",
    right: "88.95%",
    bottom: "28.35%",
    left: "5.53%",
  },
  vectorIcon4: {
    top: 18,
    right: 23,
    width: 22,
    height: 19,
    position: "absolute",
  },
  search: {
    height: 56,
    top: 0,
    backgroundColor: Color.ew,
  },
  searchBar: {
    top: 267,
    left: 25,
    height: 359,
    width: 381,
    position: "absolute",
  },
  text38: {
    width: 53,
  },
  button4: {
    left: 334,
    borderTopLeftRadius: Border.br_xl,
    borderBottomLeftRadius: Border.br_xl,
    width: 75,
    alignItems: "flex-end",
    paddingHorizontal: Padding.p_9xs,
    paddingVertical: Padding.p_8xs,
    height: 38,
    borderWidth: 2,
    borderColor: Color.ew,
    top: 62,
    borderStyle: "solid",
    position: "absolute",
  },
  service: {
    width: 56,
    height: 23,
    fontFamily: FontFamily.poppinsRegular,
    lineHeight: 30,
    fontSize: FontSize.size_mini,
    textAlign: "left",
    color: Color.ew,
  },
  button3: {
    left: 225,
    width: 96,
    paddingVertical: Padding.p_10xs,
  },
  account: {
    width: 64,
  },
  button2: {
    left: 112,
    width: 101,
    paddingVertical: Padding.p_8xs,
  },
  general: {
    width: 74,
    height: 18,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.iOSFFFFFF,
    lineHeight: 18,
    fontSize: FontSize.iOSMediumBody_size,
    textAlign: "center",
  },
  button1: {
    borderRadius: Border.br_xl,
    width: 100,
    height: 38,
    top: 62,
    backgroundColor: Color.colorTomato_500,
    left: 0,
    justifyContent: "center",
  },
  faqButtonChild: {
    left: 189,
    backgroundColor: Color.colorDarkgray_200,
    width: 192,
    height: 2,
  },
  contactUs: {
    top: 1,
    left: 241,
    color: Color.colorDarkgray_200,
    height: 19,
    display: "flex",
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    width: 100,
    fontSize: FontSize.iOSDefaultBody_size,
  },
  faqButtonItem: {
    left: 1,
    width: 190,
    height: 4,
    backgroundColor: Color.colorTomato_500,
  },
  faq: {
    left: 77,
    fontSize: FontSize.size_lgi,
    width: 41,
    height: 19,
    top: 0,
    color: Color.ew,
    textAlign: "left",
    alignItems: "center",
    position: "absolute",
  },
  faqButton: {
    top: 143,
    left: 24,
    width: 409,
    height: 100,
    position: "absolute",
  },
  time: {
    fontSize: FontSize.size_mini,
    width: 54,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    lineHeight: 18,
    letterSpacing: 0,
    left: 0,
    top: 0,
    color: Color.ew,
    textAlign: "center",
  },
  action: {
    top: 14,
    left: 20,
    height: 18,
  },
  containerIcon: {
    marginTop: -5.84,
    top: "50%",
    right: 15,
    width: 67,
    height: 12,
    position: "absolute",
  },
  statusBar: {
    marginLeft: -170,
    top: 12,
    width: 375,
    height: 44,
  },
  helpCenter2: {
    width: "100%",
    height: 975,
    flex: 1,
    backgroundColor: Color.iOSFFFFFF,
  },
});

export default HelpCenter2;
