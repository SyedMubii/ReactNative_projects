import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Color, FontFamily, FontSize, Padding, Border } from "../GlobalStyles";

const Card = () => {
  return (
    <View style={styles.card}>
      <View style={styles.peopleBusService}>
        <Image
          style={[styles.vectorIcon, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector68.png")}
        />
        <Text style={styles.addNewCard}>Add New Card</Text>
        <Image
          style={[styles.vectorIcon1, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector69.png")}
        />
      </View>
      <View style={styles.creditCard}>
        <LinearGradient
          style={styles.creditCardChild}
          locations={[0, 0, 0.88]}
          colors={["rgba(186, 188, 89, 0)", "#0a397e", "#703c6d"]}
        />
        <Image
          style={[styles.vectorIcon2, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector70.png")}
        />
        <Text style={[styles.fyiBank, styles.textLayout]}>FYI BANK</Text>
        <Text style={[styles.validThru, styles.textFlexBox]}>VALID THRU</Text>
        <Text style={[styles.okechukwuOzioma, styles.textTypo1]}>
          Okechukwu Ozioma
        </Text>
        <Text style={[styles.text, styles.textTypo1]}>0000 2363 8364 8269</Text>
        <Text style={[styles.text1, styles.textLayout]}>5/23</Text>
        <Text style={[styles.text2, styles.textLayout]}>633</Text>
        <Text style={[styles.credit, styles.textLayout]}>CREDIT</Text>
        <Text style={[styles.masterCard, styles.textFlexBox]}>MASTER CARD</Text>
        <Image
          style={[styles.masterCardLogo, styles.masterCardLogoLayout]}
          contentFit="cover"
          source={require("../assets/master-card-logo.png")}
        />
        <Image
          style={[styles.evawifiOutlineIcon, styles.masterCardLogoLayout]}
          contentFit="cover"
          source={require("../assets/evawifioutline.png")}
        />
        <View style={styles.view}>
          <Text style={[styles.text3, styles.textTypo]}>
            2345 5567 8673 0769
          </Text>
        </View>
        <View style={styles.view1}>
          <Text style={[styles.lenaRose, styles.textTypo]}>Lena Rose</Text>
        </View>
        <View style={[styles.view2, styles.viewLayout]}>
          <Text style={[styles.text4, styles.textTypo]}>09/07/26</Text>
        </View>
        <View style={[styles.view3, styles.viewLayout]}>
          <Text style={[styles.text4, styles.textTypo]}>09/07/26</Text>
        </View>
        <View style={[styles.view4, styles.viewLayout]}>
          <Text style={[styles.text4, styles.textTypo]}>026</Text>
        </View>
        <Text style={[styles.cardName, styles.cardTypo]}>Card Name</Text>
        <Text style={[styles.cardNumber, styles.cardTypo]}>Card Number</Text>
        <Text style={[styles.expiryDate, styles.cvvTypo]}>Expiry Date</Text>
        <Text style={[styles.cvv, styles.cvvTypo]}>cvv</Text>
        <Image
          style={[styles.calendarAltIcon, styles.textLayout]}
          contentFit="cover"
          source={require("../assets/calendaralt.png")}
        />
      </View>
      <LinearGradient
        style={styles.button}
        locations={[0, 1]}
        colors={["rgba(240, 0, 0, 0.96)", "#dc281e"]}
      >
        <Text style={styles.addNewCard1}>Add New Card</Text>
      </LinearGradient>
      <View style={styles.statusBar}>
        <View style={[styles.action, styles.timeLayout]}>
          <Text style={[styles.time, styles.timeLayout]}>9:41</Text>
        </View>
        <Image
          style={styles.containerIcon}
          contentFit="cover"
          source={require("../assets/container.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  vectorIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  textLayout: {
    height: 25,
    position: "absolute",
  },
  textFlexBox: {
    textAlign: "left",
    color: Color.iOSFFFFFF,
  },
  textTypo1: {
    left: 23,
    height: 25,
    textAlign: "left",
    color: Color.iOSFFFFFF,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    fontSize: FontSize.iOSMediumBody_size,
    position: "absolute",
  },
  masterCardLogoLayout: {
    height: 39,
    position: "absolute",
  },
  textTypo: {
    display: "flex",
    alignItems: "center",
    textAlign: "left",
    color: Color.iOSFFFFFF,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
  },
  viewLayout: {
    paddingVertical: Padding.p_smi,
    height: 59,
    width: 180,
    top: 569,
    backgroundColor: Color.colorTomato_200,
    paddingHorizontal: Padding.p_3xs,
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  cardTypo: {
    letterSpacing: -1,
    left: 5,
    fontSize: FontSize.size_xl,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    color: Color.ew,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    position: "absolute",
  },
  cvvTypo: {
    top: 526,
    letterSpacing: -1,
    fontSize: FontSize.size_xl,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    color: Color.ew,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    position: "absolute",
  },
  timeLayout: {
    width: 54,
    position: "absolute",
  },
  vectorIcon: {
    height: "66.67%",
    width: "4.39%",
    top: "33.33%",
    right: "95.53%",
    bottom: "0%",
    left: "0.08%",
  },
  addNewCard: {
    bottom: 0,
    fontSize: FontSize.size_6xl,
    width: 229,
    textAlign: "center",
    color: Color.ew,
    fontFamily: FontFamily.poppinsSemiBold,
    lineHeight: 18,
    letterSpacing: 0,
    left: 0,
    fontWeight: "600",
    position: "absolute",
  },
  vectorIcon1: {
    height: "91.15%",
    width: "6.86%",
    top: "0%",
    right: "0%",
    bottom: "8.85%",
    left: "93.14%",
  },
  peopleBusService: {
    top: 81,
    left: 32,
    width: 368,
    height: 24,
    position: "absolute",
  },
  creditCardChild: {
    marginLeft: -209,
    borderRadius: 30,
    height: 248,
    backgroundColor: "transparent",
    left: "50%",
    top: 0,
    width: 418,
    position: "absolute",
  },
  vectorIcon2: {
    height: "5.29%",
    width: "8.22%",
    top: "3.88%",
    right: "86.18%",
    bottom: "90.83%",
    left: "5.59%",
  },
  fyiBank: {
    top: 25,
    left: 67,
    width: 103,
    textAlign: "left",
    color: Color.iOSFFFFFF,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    height: 25,
    fontSize: FontSize.iOSMediumBody_size,
  },
  validThru: {
    top: 154,
    left: 54,
    fontSize: 6,
    fontWeight: "500",
    fontFamily: FontFamily.interMedium,
    width: 28,
    height: 18,
    position: "absolute",
  },
  okechukwuOzioma: {
    top: 210,
    width: 212,
  },
  text: {
    top: 93,
    width: 265,
  },
  text1: {
    top: 151,
    left: 81,
    width: 52,
    textAlign: "left",
    color: Color.iOSFFFFFF,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    height: 25,
    fontSize: FontSize.iOSMediumBody_size,
  },
  text2: {
    top: 146,
    left: 228,
    width: 44,
    textAlign: "left",
    color: Color.iOSFFFFFF,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    height: 25,
    fontSize: FontSize.iOSMediumBody_size,
  },
  credit: {
    top: 21,
    left: 319,
    width: 83,
    textAlign: "left",
    color: Color.iOSFFFFFF,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    height: 25,
    fontSize: FontSize.iOSMediumBody_size,
  },
  masterCard: {
    top: 219,
    left: 312,
    fontSize: FontSize.size_xs,
    textTransform: "lowercase",
    fontFamily: FontFamily.interSemiBold,
    width: 98,
    height: 19,
    fontWeight: "600",
    color: Color.iOSFFFFFF,
    position: "absolute",
  },
  masterCardLogo: {
    top: 175,
    left: 323,
    width: 65,
  },
  evawifiOutlineIcon: {
    top: 85,
    left: 346,
    width: 41,
    overflow: "hidden",
  },
  text3: {
    width: 251,
    alignItems: "center",
    fontSize: FontSize.iOSDefaultTitle2_size,
    display: "flex",
  },
  view: {
    top: 443,
    backgroundColor: Color.colorTomato_700,
    paddingVertical: 0,
    paddingHorizontal: Padding.p_3xs,
    height: 67,
    width: 380,
    borderRadius: Border.br_3xs,
    justifyContent: "center",
    left: 19,
    position: "absolute",
  },
  lenaRose: {
    width: 121,
    alignItems: "center",
    fontSize: FontSize.iOSDefaultTitle2_size,
    display: "flex",
  },
  view1: {
    top: 320,
    backgroundColor: Color.colorTomato_200,
    paddingVertical: 0,
    paddingHorizontal: Padding.p_3xs,
    justifyContent: "center",
    height: 67,
    width: 380,
    borderRadius: Border.br_3xs,
    left: 19,
    position: "absolute",
  },
  text4: {
    width: 80,
    height: 31,
    alignItems: "center",
    display: "flex",
    fontSize: FontSize.iOSMediumBody_size,
  },
  view2: {
    opacity: 0.1,
    left: 19,
    paddingVertical: Padding.p_smi,
    height: 59,
    width: 180,
    top: 569,
  },
  view3: {
    left: 19,
    paddingVertical: Padding.p_smi,
    height: 59,
    width: 180,
    top: 569,
  },
  view4: {
    left: 219,
  },
  cardName: {
    top: 278,
    width: 119,
  },
  cardNumber: {
    top: 402,
    width: 138,
  },
  expiryDate: {
    left: 9,
    width: 138,
  },
  cvv: {
    width: 42,
    left: 219,
  },
  calendarAltIcon: {
    top: 582,
    left: 154,
    width: 25,
    overflow: "hidden",
  },
  creditCard: {
    top: 173,
    left: 7,
    height: 628,
    width: 418,
    position: "absolute",
  },
  addNewCard1: {
    fontFamily: FontFamily.poppinsBold,
    fontSize: FontSize.size_xl,
    textAlign: "left",
    color: Color.iOSFFFFFF,
    fontWeight: "700",
  },
  button: {
    top: 853,
    left: 53,
    borderRadius: Border.br_17xl,
    width: 321,
    height: 54,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "transparent",
    position: "absolute",
  },
  time: {
    fontSize: FontSize.size_mini,
    top: 0,
    width: 54,
    textAlign: "center",
    color: Color.ew,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    lineHeight: 18,
    letterSpacing: 0,
    left: 0,
  },
  action: {
    top: 14,
    left: 20,
    height: 18,
  },
  containerIcon: {
    marginTop: -5.84,
    top: "50%",
    right: 15,
    width: 67,
    height: 12,
    position: "absolute",
  },
  statusBar: {
    marginLeft: -185,
    top: 9,
    width: 375,
    height: 44,
    left: "50%",
    position: "absolute",
  },
  card: {
    backgroundColor: Color.iOSFFFFFF,
    flex: 1,
    width: "100%",
    height: 981,
  },
});

export default Card;
