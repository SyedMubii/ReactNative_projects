import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const Profile17 = () => {
  return (
    <View style={styles.profile17}>
      <View style={[styles.frameNave, styles.frameLayout]}>
        <View style={[styles.frameNaveChild, styles.frameLayout]} />
        <View style={[styles.instanceParent, styles.searchLayout]}>
          <Image
            style={styles.frameChild}
            contentFit="cover"
            source={require("../assets/group-125.png")}
          />
          <Image
            style={styles.userAltIcon}
            contentFit="cover"
            source={require("../assets/useralt1.png")}
          />
          <View style={styles.homeParent}>
            <Text style={[styles.home, styles.homeClr]}>Home</Text>
            <Text style={[styles.schedule, styles.abcdefghijlTypo]}>
              Schedule
            </Text>
            <Text style={[styles.ePay, styles.abcdefghijlTypo]}>E Pay</Text>
            <Text style={[styles.profile, styles.foundTypo]}>Profile</Text>
          </View>
          <Image
            style={[styles.vectorIcon, styles.vectorIconLayout]}
            contentFit="cover"
            source={require("../assets/vector21.png")}
          />
          <Image
            style={[styles.vectorIcon1, styles.vectorIconLayout]}
            contentFit="cover"
            source={require("../assets/vector22.png")}
          />
        </View>
      </View>
      <View style={styles.dealsSection}>
        <Text style={[styles.resultsForAbcdefghijl, styles.abcdefghijlTypo]}>
          Results for “Abcdefghijl “
        </Text>
        <Text style={[styles.found, styles.foundTypo]}>0 found</Text>
      </View>
      <View style={styles.dealsSection1}>
        <Text
          style={styles.sorryTheKeyword}
        >{`Sorry, the keyword you entered cannot be
 found, please check again or search with
 another keyword.`}</Text>
        <Text style={styles.notFound}>Not Found</Text>
      </View>
      <View style={[styles.search, styles.searchLayout]}>
        <Text style={[styles.abcdefghijl, styles.abcdefghijlTypo]}>
          Abcdefghijl
        </Text>
        <Image
          style={[styles.vectorIcon2, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector4.png")}
        />
        <Image
          style={styles.vectorIcon3}
          contentFit="cover"
          source={require("../assets/vector5.png")}
        />
      </View>
      <Image
        style={styles.noProduct1Icon}
        contentFit="cover"
        source={require("../assets/noproduct-1.png")}
      />
      <View style={styles.statusBar}>
        <View style={[styles.action, styles.timeLayout]}>
          <Text style={[styles.time, styles.timeLayout]}>9:41</Text>
        </View>
        <Image
          style={styles.containerIcon}
          contentFit="cover"
          source={require("../assets/container.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  frameLayout: {
    height: 100,
    width: 428,
    left: 0,
    position: "absolute",
  },
  searchLayout: {
    height: 56,
    position: "absolute",
  },
  homeClr: {
    color: Color.iOSFFFFFF,
    fontSize: FontSize.size_sm,
  },
  abcdefghijlTypo: {
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    position: "absolute",
  },
  foundTypo: {
    top: 1,
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    position: "absolute",
  },
  vectorIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  timeLayout: {
    width: 54,
    position: "absolute",
  },
  frameNaveChild: {
    borderTopLeftRadius: Border.br_5xl,
    borderTopRightRadius: Border.br_5xl,
    backgroundColor: Color.colorTomato_100,
    top: 0,
  },
  frameChild: {
    left: 4,
    width: 33,
    height: 33,
    top: 0,
    position: "absolute",
  },
  userAltIcon: {
    top: 3,
    left: 314,
    width: 28,
    height: 28,
    overflow: "hidden",
    position: "absolute",
  },
  home: {
    textAlign: "center",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    top: 0,
    left: 0,
    position: "absolute",
  },
  schedule: {
    left: 80,
    color: Color.iOSFFFFFF,
    fontSize: FontSize.size_sm,
    top: 0,
  },
  ePay: {
    left: 200,
    color: Color.iOSFFFFFF,
    fontSize: FontSize.size_sm,
    top: 0,
  },
  profile: {
    left: 307,
    color: Color.iOSFFFFFF,
    fontSize: FontSize.size_sm,
  },
  homeParent: {
    top: 34,
    height: 22,
    width: 352,
    left: 0,
    position: "absolute",
  },
  vectorIcon: {
    width: "10.24%",
    top: "7.75%",
    right: "32.16%",
    bottom: "42.48%",
    left: "57.59%",
    height: "49.77%",
    maxHeight: "100%",
    maxWidth: "100%",
  },
  vectorIcon1: {
    width: "7.17%",
    top: "2.41%",
    right: "63.66%",
    bottom: "47.82%",
    left: "29.17%",
    height: "49.77%",
    maxHeight: "100%",
    maxWidth: "100%",
  },
  instanceParent: {
    top: 19,
    left: 41,
    width: 352,
  },
  frameNave: {
    top: 826,
    display: "none",
  },
  resultsForAbcdefghijl: {
    fontSize: FontSize.size_lg,
    color: Color.ew,
    top: 0,
    left: 0,
  },
  found: {
    left: 321,
    fontSize: FontSize.iOSMediumBody_size,
    width: 77,
    color: Color.ew,
  },
  dealsSection: {
    top: 146,
    left: 25,
    width: 398,
    height: 27,
    position: "absolute",
  },
  sorryTheKeyword: {
    top: 42,
    fontSize: FontSize.iOSDefaultBody_size,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.ew,
    textAlign: "center",
    left: 0,
    position: "absolute",
  },
  notFound: {
    left: 118,
    fontSize: FontSize.iOSDefaultTitle2_size,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: Color.ew,
    textAlign: "center",
    top: 0,
    position: "absolute",
  },
  dealsSection1: {
    top: 580,
    left: 43,
    width: 354,
    height: 120,
    position: "absolute",
  },
  abcdefghijl: {
    top: 21,
    left: 52,
    fontSize: FontSize.size_smi,
    color: Color.colorGray_200,
    display: "flex",
    alignItems: "center",
    width: 91,
    height: 14,
  },
  vectorIcon2: {
    height: "37.53%",
    width: "5.53%",
    top: "34.13%",
    right: "88.95%",
    bottom: "28.35%",
    left: "5.53%",
  },
  vectorIcon3: {
    top: 18,
    right: 23,
    width: 22,
    height: 19,
    position: "absolute",
  },
  search: {
    top: 68,
    left: 23,
    borderRadius: Border.br_3xs,
    backgroundColor: Color.colorSilver_100,
    width: 380,
  },
  noProduct1Icon: {
    top: 283,
    left: 74,
    width: 289,
    height: 274,
    position: "absolute",
  },
  time: {
    fontSize: FontSize.size_mini,
    letterSpacing: 0,
    lineHeight: 18,
    color: Color.ew,
    textAlign: "center",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    top: 0,
    left: 0,
  },
  action: {
    top: 14,
    left: 20,
    height: 18,
  },
  containerIcon: {
    marginTop: -5.84,
    top: "50%",
    right: 15,
    width: 67,
    height: 12,
    position: "absolute",
  },
  statusBar: {
    marginLeft: -183,
    top: 9,
    left: "50%",
    width: 375,
    height: 44,
    position: "absolute",
  },
  profile17: {
    backgroundColor: Color.iOSFFFFFF,
    flex: 1,
    width: "100%",
    height: 926,
  },
});

export default Profile17;
