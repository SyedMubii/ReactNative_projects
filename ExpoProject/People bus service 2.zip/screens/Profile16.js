import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Color, Border, Padding, FontSize } from "../GlobalStyles";

const Profile16 = () => {
  const navigation = useNavigation();

  return (
    <Pressable
      style={styles.profile16}
      onPress={() => navigation.navigate("Profile17")}
    >
      <View style={styles.dealsSection}>
        <View style={[styles.g8, styles.g8Layout]}>
          <Text style={[styles.landhiRoad, styles.landhiRoadFlexBox]}>
            Landhi Road
          </Text>
          <Image
            style={[styles.vectorIcon, styles.vectorIconLayout]}
            contentFit="cover"
            source={require("../assets/vector20.png")}
          />
        </View>
        <View style={[styles.g7, styles.g8Layout]}>
          <Text style={[styles.shahFaisalColony, styles.landhiRoadFlexBox]}>
            Shah Faisal Colony
          </Text>
          <Image
            style={[styles.vectorIcon, styles.vectorIconLayout]}
            contentFit="cover"
            source={require("../assets/vector20.png")}
          />
        </View>
        <View style={[styles.g6, styles.g8Layout]}>
          <Text style={[styles.landhiRoad, styles.landhiRoadFlexBox]}>
            NIPA
          </Text>
          <Image
            style={[styles.vectorIcon, styles.vectorIconLayout]}
            contentFit="cover"
            source={require("../assets/vector20.png")}
          />
        </View>
        <View style={[styles.g5, styles.g8Layout]}>
          <Text style={[styles.landhiRoad, styles.landhiRoadFlexBox]}>
            Indus Hospital
          </Text>
          <Image
            style={[styles.vectorIcon, styles.vectorIconLayout]}
            contentFit="cover"
            source={require("../assets/vector20.png")}
          />
        </View>
        <View style={[styles.g4, styles.g8Layout]}>
          <Text style={[styles.landhiRoad, styles.landhiRoadFlexBox]}>
            Dockyard
          </Text>
          <Image
            style={[styles.vectorIcon, styles.vectorIconLayout]}
            contentFit="cover"
            source={require("../assets/vector20.png")}
          />
        </View>
        <View style={[styles.g3, styles.g8Layout]}>
          <Text style={[styles.landhiRoad, styles.landhiRoadFlexBox]}>
            PAF Base
          </Text>
          <Image
            style={[styles.vectorIcon, styles.vectorIconLayout]}
            contentFit="cover"
            source={require("../assets/vector20.png")}
          />
        </View>
        <View style={[styles.g2, styles.g8Layout]}>
          <Text style={[styles.landhiRoad, styles.landhiRoadFlexBox]}>
            I.I Chundrigar
          </Text>
          <Image
            style={[styles.vectorIcon, styles.vectorIconLayout]}
            contentFit="cover"
            source={require("../assets/vector20.png")}
          />
        </View>
        <View style={[styles.g1, styles.g8Layout]}>
          <Text style={[styles.shahFaisalColony, styles.landhiRoadFlexBox]}>
            Drigh Road Station
          </Text>
          <Image
            style={[styles.vectorIcon, styles.vectorIconLayout]}
            contentFit="cover"
            source={require("../assets/vector20.png")}
          />
        </View>
        <Text style={[styles.recentlySearch, styles.timeTypo]}>
          Recently Search
        </Text>
        <Text style={styles.clearAll}>Clear All</Text>
      </View>
      <View style={styles.search}>
        <Text style={styles.abcdefghijl}>Abcdefghijl</Text>
        <Image
          style={[styles.vectorIcon8, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector4.png")}
        />
        <Image
          style={styles.vectorIcon9}
          contentFit="cover"
          source={require("../assets/vector5.png")}
        />
      </View>
      <View
        style={[styles.keyboardsiosAlphbeticKeyboa, styles.statusBarPosition]}
      >
        <View style={[styles.componentSuggestionBar, styles.componentFlexBox1]}>
          <View style={styles.componentItemFlexBox}>
            <Text style={styles.text} numberOfLines={1}>
              Suggest
            </Text>
          </View>
          <Image
            style={styles.seperatorIcon}
            contentFit="cover"
            source={require("../assets/seperator.png")}
          />
          <View
            style={[
              styles.componentSuggestionItem1,
              styles.componentItemFlexBox,
            ]}
          >
            <Text style={styles.text} numberOfLines={1}>
              Suggest
            </Text>
          </View>
          <Image
            style={styles.seperatorIcon}
            contentFit="cover"
            source={require("../assets/seperator1.png")}
          />
          <View
            style={[
              styles.componentSuggestionItem1,
              styles.componentItemFlexBox,
            ]}
          >
            <Text style={styles.text} numberOfLines={1}>
              Suggest
            </Text>
          </View>
        </View>
        <View style={styles.iosAlphbeticKeyboardEngli}>
          <View
            style={[styles.componentSuggestionBar, styles.componentFlexBox1]}
          >
            <View style={styles.componentItemFlexBox}>
              <Text style={styles.text} numberOfLines={1}>
                Suggest
              </Text>
            </View>
            <Image
              style={styles.seperatorIcon}
              contentFit="cover"
              source={require("../assets/seperator.png")}
            />
            <View
              style={[
                styles.componentSuggestionItem1,
                styles.componentItemFlexBox,
              ]}
            >
              <Text style={styles.text} numberOfLines={1}>
                Suggest
              </Text>
            </View>
            <Image
              style={styles.seperatorIcon}
              contentFit="cover"
              source={require("../assets/seperator1.png")}
            />
            <View
              style={[
                styles.componentSuggestionItem1,
                styles.componentItemFlexBox,
              ]}
            >
              <Text style={styles.text} numberOfLines={1}>
                Suggest
              </Text>
            </View>
          </View>
          <View style={[styles.keysLayoutAlphabeticEng, styles.componentBg]}>
            <View style={styles.rowAlphabetic}>
              <View style={styles.componentShadowBox3}>
                <Text style={[styles.text6, styles.textTypo]}>q</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>w</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>e</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>r</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>t</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>y</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>u</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>i</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>o</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>p</Text>
              </View>
            </View>
            <View style={[styles.rowAlphabetic1, styles.rowFlexBox]}>
              <View style={styles.componentShadowBox3}>
                <Text style={[styles.text6, styles.textTypo]}>a</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>s</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>d</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>f</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>g</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>h</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>j</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>k</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text6, styles.textTypo]}>l</Text>
              </View>
            </View>
            <View style={styles.rowFlexBox}>
              <View style={[styles.componentKey19, styles.componentShadowBox1]}>
                <Text style={[styles.text25, styles.spaceTypo]}>􀆝</Text>
              </View>
              <View
                style={[styles.rowAlphabetic2, styles.rowAlphabetic2SpaceBlock]}
              >
                <View style={styles.componentShadowBox3}>
                  <Text style={[styles.text6, styles.textTypo]}>z</Text>
                </View>
                <View style={styles.componentShadowBox2}>
                  <Text style={[styles.text6, styles.textTypo]}>x</Text>
                </View>
                <View style={styles.componentShadowBox2}>
                  <Text style={[styles.text6, styles.textTypo]}>c</Text>
                </View>
                <View style={styles.componentShadowBox2}>
                  <Text style={[styles.text6, styles.textTypo]}>v</Text>
                </View>
                <View style={styles.componentShadowBox2}>
                  <Text style={[styles.text6, styles.textTypo]}>b</Text>
                </View>
                <View style={styles.componentShadowBox2}>
                  <Text style={[styles.text6, styles.textTypo]}>n</Text>
                </View>
                <View style={styles.componentShadowBox2}>
                  <Text style={[styles.text6, styles.textTypo]}>m</Text>
                </View>
              </View>
              <View style={[styles.componentKey27, styles.componentFlexBox]}>
                <Text style={[styles.text25, styles.spaceTypo]}>􀆛</Text>
              </View>
            </View>
            <View style={styles.rowFlexBox}>
              <View style={[styles.componentKey28, styles.componentFlexBox]}>
                <Text style={[styles.text25, styles.spaceTypo]}>123</Text>
              </View>
              <View style={[styles.componentKey29, styles.componentShadowBox]}>
                <Text style={styles.spaceTypo}>space</Text>
              </View>
              <View style={[styles.componentKey30, styles.componentShadowBox]}>
                <Text style={[styles.text25, styles.spaceTypo]}>Go</Text>
              </View>
            </View>
          </View>
          <View style={[styles.componentHomeIndicatorSec, styles.componentBg]}>
            <View style={styles.keys}>
              <View style={styles.componentKey31}>
                <Text style={[styles.text36, styles.textTypo]}>􀎸</Text>
              </View>
              <View style={styles.componentKey31}>
                <Text style={[styles.text36, styles.textTypo]}>􀊰</Text>
              </View>
            </View>
            <View
              style={[styles.componentHomeIndicator, styles.componentFlexBox1]}
            >
              <View style={styles.indicator} />
            </View>
          </View>
        </View>
      </View>
      <View style={[styles.statusBar, styles.statusBarPosition]}>
        <View style={[styles.action, styles.timeLayout]}>
          <Text style={[styles.time, styles.timeLayout]}>9:41</Text>
        </View>
        <Image
          style={styles.containerIcon}
          contentFit="cover"
          source={require("../assets/container.png")}
        />
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  g8Layout: {
    height: 30,
    width: 371,
    left: 1,
    position: "absolute",
  },
  landhiRoadFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  vectorIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  timeTypo: {
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    color: Color.ew,
    left: 0,
    top: 0,
  },
  statusBarPosition: {
    left: "50%",
    position: "absolute",
  },
  componentFlexBox1: {
    justifyContent: "center",
    alignItems: "center",
  },
  componentItemFlexBox: {
    height: 34,
    borderRadius: Border.br_8xs_6,
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  componentBg: {
    backgroundColor: Color.iOSAlfaCCCED376,
    alignSelf: "stretch",
  },
  textTypo: {
    fontFamily: FontFamily.iOSDefaultTitle2,
    textAlign: "center",
  },
  rowFlexBox: {
    marginTop: 12,
    flexDirection: "row",
    alignSelf: "stretch",
  },
  componentShadowBox1: {
    padding: Padding.p_2xs,
    height: 42,
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "#898a8d",
    borderRadius: Border.br_8xs_6,
    overflow: "hidden",
  },
  spaceTypo: {
    lineHeight: 21,
    textAlign: "center",
    fontFamily: FontFamily.iOSMediumBody,
    fontSize: FontSize.iOSMediumBody_size,
    color: Color.ew,
    flex: 1,
  },
  rowAlphabetic2SpaceBlock: {
    marginLeft: 1,
    flexDirection: "row",
  },
  componentFlexBox: {
    backgroundColor: Color.iOSADB3BC,
    justifyContent: "center",
    alignItems: "center",
  },
  componentShadowBox: {
    marginLeft: 6,
    padding: Padding.p_2xs,
    height: 42,
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "#898a8d",
    borderRadius: Border.br_8xs_6,
    flexDirection: "row",
    overflow: "hidden",
  },
  timeLayout: {
    width: 54,
    position: "absolute",
  },
  landhiRoad: {
    width: 141,
    color: Color.ew,
    fontFamily: FontFamily.poppinsRegular,
    lineHeight: 30,
    letterSpacing: -0.4,
    fontSize: FontSize.size_xl,
    left: 0,
    top: 0,
    textAlign: "left",
  },
  vectorIcon: {
    height: "38.89%",
    width: "3.15%",
    top: "30%",
    right: "0%",
    bottom: "31.11%",
    left: "96.85%",
  },
  g8: {
    top: 437,
  },
  shahFaisalColony: {
    width: 189,
    color: Color.ew,
    fontFamily: FontFamily.poppinsRegular,
    lineHeight: 30,
    letterSpacing: -0.4,
    fontSize: FontSize.size_xl,
    left: 0,
    top: 0,
    textAlign: "left",
  },
  g7: {
    top: 385,
  },
  g6: {
    top: 333,
  },
  g5: {
    top: 281,
  },
  g4: {
    top: 229,
  },
  g3: {
    top: 177,
  },
  g2: {
    top: 125,
  },
  g1: {
    top: 73,
  },
  recentlySearch: {
    fontSize: FontSize.size_lg,
    textAlign: "left",
    position: "absolute",
  },
  clearAll: {
    top: 1,
    left: 313,
    width: 77,
    fontSize: FontSize.iOSMediumBody_size,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    textAlign: "left",
    color: Color.ew,
    position: "absolute",
  },
  dealsSection: {
    top: 146,
    left: 24,
    width: 390,
    height: 467,
    position: "absolute",
  },
  abcdefghijl: {
    top: 21,
    left: 52,
    fontSize: FontSize.size_smi,
    color: Color.colorGray_200,
    display: "flex",
    width: 91,
    height: 14,
    alignItems: "center",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    textAlign: "left",
    position: "absolute",
  },
  vectorIcon8: {
    height: "37.53%",
    width: "5.53%",
    top: "34.13%",
    right: "88.95%",
    bottom: "28.35%",
    left: "5.53%",
  },
  vectorIcon9: {
    top: 18,
    right: 23,
    width: 22,
    height: 19,
    position: "absolute",
  },
  search: {
    top: 68,
    left: 23,
    borderRadius: Border.br_3xs,
    backgroundColor: Color.colorSilver_100,
    width: 380,
    height: 56,
    position: "absolute",
  },
  text: {
    fontSize: FontSize.iOSDefaultBody_size,
    lineHeight: 20,
    color: Color.iOS3A3B3D,
    height: 20,
    textAlign: "center",
    fontFamily: FontFamily.iOSMediumBody,
    overflow: "hidden",
    flex: 1,
  },
  seperatorIcon: {
    width: 0,
    height: 24,
    marginLeft: 2,
  },
  componentSuggestionItem1: {
    marginLeft: 2,
  },
  componentSuggestionBar: {
    paddingHorizontal: Padding.p_12xs,
    paddingTop: Padding.p_3xs,
    display: "none",
    flexDirection: "row",
    backgroundColor: Color.iOSAlfaCCCED376,
    alignSelf: "stretch",
    overflow: "hidden",
    justifyContent: "center",
  },
  text6: {
    fontSize: FontSize.iOSDefaultTitle2_size,
    lineHeight: 28,
    color: Color.ew,
    flex: 1,
  },
  componentShadowBox3: {
    padding: Padding.p_6xs,
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "#898a8d",
    borderRadius: Border.br_8xs_6,
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center",
    overflow: "hidden",
    flex: 1,
    backgroundColor: Color.iOSFFFFFF,
  },
  componentShadowBox2: {
    marginLeft: 5,
    padding: Padding.p_6xs,
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "#898a8d",
    borderRadius: Border.br_8xs_6,
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center",
    overflow: "hidden",
    flex: 1,
    backgroundColor: Color.iOSFFFFFF,
  },
  rowAlphabetic: {
    flexDirection: "row",
    alignSelf: "stretch",
  },
  rowAlphabetic1: {
    paddingHorizontal: Padding.p_lg,
    paddingVertical: 0,
  },
  text25: {
    height: 20,
  },
  componentKey19: {
    width: 42,
    padding: Padding.p_2xs,
    height: 42,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    backgroundColor: Color.iOSFFFFFF,
  },
  rowAlphabetic2: {
    paddingHorizontal: Padding.p_smi,
    paddingVertical: 0,
    flex: 1,
  },
  componentKey27: {
    marginLeft: 1,
    flexDirection: "row",
    padding: Padding.p_2xs,
    height: 42,
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "#898a8d",
    borderRadius: Border.br_8xs_6,
    overflow: "hidden",
    width: 42,
  },
  componentKey28: {
    width: 87,
    padding: Padding.p_2xs,
    height: 42,
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "#898a8d",
    borderRadius: Border.br_8xs_6,
    overflow: "hidden",
    flexDirection: "row",
  },
  componentKey29: {
    flex: 1,
    backgroundColor: Color.iOSFFFFFF,
  },
  componentKey30: {
    width: 88,
    backgroundColor: Color.iOSADB3BC,
    justifyContent: "center",
    alignItems: "center",
  },
  keysLayoutAlphabeticEng: {
    paddingHorizontal: Padding.p_10xs,
    paddingVertical: Padding.p_5xs,
  },
  text36: {
    fontSize: FontSize.size_7xl,
    color: Color.iOS50555C,
  },
  componentKey31: {
    width: 47,
    height: 47,
    padding: Padding.p_5xs,
    borderRadius: Border.br_8xs_6,
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center",
    overflow: "hidden",
  },
  keys: {
    justifyContent: "space-between",
    paddingHorizontal: Padding.p_xl,
    paddingTop: Padding.p_4xs,
    flexDirection: "row",
    alignSelf: "stretch",
  },
  indicator: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.ew,
    width: 134,
    height: 5,
  },
  componentHomeIndicator: {
    paddingHorizontal: Padding.p_101xl,
    paddingTop: Padding.p_12xs,
    paddingBottom: Padding.p_4xs,
    alignSelf: "stretch",
  },
  componentHomeIndicatorSec: {
    justifyContent: "flex-end",
  },
  iosAlphbeticKeyboardEngli: {
    width: 428,
  },
  keyboardsiosAlphbeticKeyboa: {
    marginLeft: -214,
    bottom: 1,
    width: 428,
  },
  time: {
    fontSize: FontSize.size_mini,
    letterSpacing: 0,
    lineHeight: 18,
    textAlign: "center",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    color: Color.ew,
    left: 0,
    top: 0,
  },
  action: {
    top: 14,
    left: 20,
    height: 18,
  },
  containerIcon: {
    marginTop: -5.84,
    top: "50%",
    right: 15,
    width: 67,
    height: 12,
    position: "absolute",
  },
  statusBar: {
    marginLeft: -183,
    top: 9,
    width: 375,
    height: 44,
  },
  profile16: {
    width: "100%",
    height: 926,
    flex: 1,
    backgroundColor: Color.iOSFFFFFF,
  },
});

export default Profile16;
