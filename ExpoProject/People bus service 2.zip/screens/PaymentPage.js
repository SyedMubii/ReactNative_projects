import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const PaymentPage = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.paymentPage}>
      <View style={styles.statusBar}>
        <View style={styles.action}>
          <Text style={styles.time}>9:41</Text>
        </View>
        <Image
          style={styles.containerIcon}
          contentFit="cover"
          source={require("../assets/container.png")}
        />
      </View>
      <View style={styles.frame}>
        <View style={styles.frame1}>
          <View style={styles.payment}>
            <Pressable
              style={styles.vector}
              onPress={() => navigation.navigate("ProfilePage")}
            >
              <Image
                style={styles.icon}
                contentFit="cover"
                source={require("../assets/vector61.png")}
              />
            </Pressable>
            <Text style={styles.payment1}>Payment</Text>
          </View>
          <View style={styles.options}>
            <View style={styles.view}>
              <Image
                style={styles.vectorIcon}
                contentFit="cover"
                source={require("../assets/vector62.png")}
              />
              <Text style={styles.jazzCash}>Jazz Cash</Text>
            </View>
            <View style={styles.frame2}>
              <View style={styles.frame3}>
                <View style={styles.view1}>
                  <View style={styles.frame4}>
                    <Image
                      style={styles.vectorIcon1}
                      contentFit="cover"
                      source={require("../assets/vector63.png")}
                    />
                    <Text style={styles.paypal}>PayPal</Text>
                  </View>
                  <Text style={styles.connected}>Connected</Text>
                </View>
                <View style={styles.view2}>
                  <Image
                    style={styles.vectorIcon}
                    contentFit="cover"
                    source={require("../assets/vector64.png")}
                  />
                  <View style={styles.frame5}>
                    <Text style={styles.googlePay}>Google Pay</Text>
                    <Text style={styles.connected1}>Connected</Text>
                  </View>
                </View>
              </View>
              <View style={styles.frame6}>
                <View style={styles.view1}>
                  <View style={styles.frame7}>
                    <Image
                      style={styles.vectorIcon}
                      contentFit="cover"
                      source={require("../assets/vector65.png")}
                    />
                    <Text style={styles.applePay}>Apple Pay</Text>
                  </View>
                  <Text style={styles.connected2}>Connected</Text>
                </View>
                <View style={styles.frame8}>
                  <View style={styles.view4}>
                    <Image
                      style={styles.vectorIcon4}
                      contentFit="cover"
                      source={require("../assets/vector66.png")}
                    />
                    <View style={styles.frame9}>
                      <Text style={styles.text}>**** **** **** 4679</Text>
                      <Text style={styles.connected3}>Connected</Text>
                    </View>
                  </View>
                  <View style={styles.view5}>
                    <Image
                      style={styles.vectorIcon5}
                      contentFit="cover"
                      source={require("../assets/vector67.png")}
                    />
                    <Text style={styles.easyPaisa}>Easy Paisa</Text>
                  </View>
                </View>
              </View>
            </View>
          </View>
        </View>
        <LinearGradient
          style={styles.button}
          locations={[0, 1]}
          colors={["rgba(240, 0, 0, 0.96)", "#dc281e"]}
        >
          <Text style={styles.addNewCard}>Add New Card</Text>
        </LinearGradient>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  time: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: FontSize.size_mini,
    letterSpacing: 0,
    lineHeight: 18,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.ew,
    textAlign: "center",
    width: 54,
  },
  action: {
    position: "absolute",
    top: 14,
    left: 20,
    width: 54,
    height: 18,
  },
  containerIcon: {
    position: "absolute",
    marginTop: -5.84,
    top: "50%",
    right: 15,
    width: 67,
    height: 12,
  },
  statusBar: {
    width: 375,
    height: 44,
    marginLeft: 9,
  },
  icon: {
    height: "100%",
    width: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
  },
  vector: {
    position: "absolute",
    left: "0%",
    top: "13.53%",
    right: "92.08%",
    bottom: "2.14%",
    width: "7.92%",
    height: "84.33%",
  },
  payment1: {
    position: "absolute",
    bottom: 0,
    left: 0,
    fontSize: FontSize.size_6xl,
    letterSpacing: 0,
    lineHeight: 18,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.ew,
    textAlign: "center",
    width: 202,
  },
  payment: {
    width: 202,
    height: 18,
    marginRight: 162,
  },
  vectorIcon: {
    position: "relative",
    width: 22,
    height: 22,
  },
  jazzCash: {
    position: "relative",
    fontSize: FontSize.iOSDefaultTitle2_size,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.iOSFFFFFF,
    textAlign: "left",
    display: "flex",
    alignItems: "center",
    width: 118,
    marginLeft: 20,
  },
  view: {
    position: "absolute",
    top: 523,
    left: 0,
    borderRadius: Border.br_3xs,
    backgroundColor: Color.colorTomato_400,
    width: 380,
    height: 67,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
    paddingHorizontal: Padding.p_lgi,
    paddingVertical: Padding.p_mid,
  },
  vectorIcon1: {
    position: "relative",
    width: 25,
    height: 25,
  },
  paypal: {
    position: "relative",
    fontSize: FontSize.iOSDefaultTitle2_size,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.iOSFFFFFF,
    textAlign: "left",
    display: "flex",
    alignItems: "center",
    width: 86,
    marginLeft: 19,
  },
  frame4: {
    width: 130,
    height: 33,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  connected: {
    position: "relative",
    fontSize: FontSize.iOSDefaultBody_size,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.iOSFFFFFF,
    textAlign: "left",
    display: "flex",
    alignItems: "center",
    width: 103,
    marginLeft: 113,
  },
  view1: {
    borderRadius: Border.br_3xs,
    backgroundColor: Color.colorTomato_400,
    width: 380,
    height: 67,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
    padding: Padding.p_mid,
  },
  googlePay: {
    position: "relative",
    fontSize: FontSize.iOSDefaultTitle2_size,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.iOSFFFFFF,
    textAlign: "left",
    display: "flex",
    alignItems: "center",
    width: 231,
  },
  connected1: {
    position: "relative",
    fontSize: FontSize.iOSDefaultBody_size,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.iOSFFFFFF,
    textAlign: "left",
    display: "flex",
    alignItems: "center",
    width: 103,
    marginLeft: -32,
  },
  frame5: {
    width: 302,
    height: 33,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-end",
    marginLeft: 20,
  },
  view2: {
    borderRadius: Border.br_3xs,
    backgroundColor: Color.colorTomato_400,
    width: 380,
    height: 67,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
    padding: Padding.p_mid,
    marginTop: 39,
  },
  frame3: {
    width: 380,
    height: 173,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  applePay: {
    position: "relative",
    fontSize: FontSize.iOSDefaultTitle2_size,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.iOSFFFFFF,
    textAlign: "left",
    display: "flex",
    alignItems: "center",
    width: 126,
    marginLeft: 21,
  },
  frame7: {
    width: 169,
    height: 33,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  connected2: {
    position: "relative",
    fontSize: FontSize.iOSDefaultBody_size,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.iOSFFFFFF,
    textAlign: "left",
    display: "flex",
    alignItems: "center",
    width: 103,
    marginLeft: 73,
  },
  vectorIcon4: {
    position: "relative",
    width: 24,
    height: 24,
  },
  text: {
    position: "relative",
    fontSize: FontSize.iOSDefaultTitle2_size,
    letterSpacing: -1.1,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.iOSFFFFFF,
    textAlign: "left",
    display: "flex",
    alignItems: "center",
    width: 194,
  },
  connected3: {
    position: "relative",
    fontSize: FontSize.iOSDefaultBody_size,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.iOSFFFFFF,
    textAlign: "left",
    display: "flex",
    alignItems: "center",
    width: 103,
    marginLeft: 5,
  },
  frame9: {
    width: 302,
    height: 33,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
    marginLeft: 18,
  },
  view4: {
    borderRadius: Border.br_3xs,
    backgroundColor: Color.colorTomato_400,
    width: 380,
    height: 67,
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
    padding: Padding.p_mid,
  },
  vectorIcon5: {
    position: "relative",
    width: 25,
    height: 20,
  },
  easyPaisa: {
    position: "relative",
    fontSize: FontSize.iOSDefaultTitle2_size,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.iOSFFFFFF,
    textAlign: "left",
    display: "flex",
    alignItems: "center",
    width: 126,
    marginLeft: 18,
  },
  view5: {
    borderRadius: Border.br_3xs,
    backgroundColor: Color.colorTomato_400,
    width: 380,
    height: 67,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
    paddingHorizontal: Padding.p_lg,
    paddingVertical: Padding.p_mid,
    marginTop: 36,
  },
  frame8: {
    width: 380,
    height: 170,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
    marginTop: 39,
  },
  frame6: {
    width: 380,
    height: 276,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
    marginTop: 39,
  },
  frame2: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 380,
    height: 488,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  options: {
    width: 380,
    height: 515,
    marginLeft: 4,
    marginTop: 69,
  },
  frame1: {
    width: 384,
    height: 603,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  addNewCard: {
    position: "relative",
    fontSize: FontSize.size_xl,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: Color.iOSFFFFFF,
    textAlign: "left",
  },
  button: {
    borderRadius: Border.br_17xl,
    width: 321,
    height: 54,
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "transparent",
    marginRight: 1,
    marginTop: 138,
  },
  frame: {
    width: 384,
    height: 795,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
    marginTop: 29,
  },
  paymentPage: {
    position: "relative",
    backgroundColor: Color.iOSFFFFFF,
    flex: 1,
    width: "100%",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-end",
    paddingHorizontal: Padding.p_3xl,
    paddingTop: Padding.p_4xs,
    paddingBottom: 48,
  },
});

export default PaymentPage;
