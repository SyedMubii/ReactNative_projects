import * as React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { Image } from "expo-image";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const HelpCenter = () => {
  return (
    <Pressable style={styles.helpCenter}>
      <View style={styles.peopleBusService}>
        <Image
          style={[styles.vectorIcon, styles.vectorIconLayout1]}
          contentFit="cover"
          source={require("../assets/vector53.png")}
        />
        <Image
          style={styles.frameIcon}
          contentFit="cover"
          source={require("../assets/frame1.png")}
        />
        <Text style={[styles.helpCenter1, styles.generalFlexBox]}>
          Help Center
        </Text>
        <Image
          style={[styles.vectorIcon1, styles.vectorIconLayout1]}
          contentFit="cover"
          source={require("../assets/vector54.png")}
        />
      </View>
      <View style={styles.searchBar}>
        <View style={[styles.view, styles.viewLayout]}>
          <Image
            style={[styles.vectorIcon2, styles.vectorIconLayout]}
            contentFit="cover"
            source={require("../assets/vector55.png")}
          />
          <Text style={[styles.whyCantI, styles.howFlexBox]}>
            Why can’t I make a payment ?
          </Text>
        </View>
        <View style={[styles.view1, styles.viewLayout]}>
          <Image
            style={[styles.vectorIcon3, styles.vectorIconLayout]}
            contentFit="cover"
            source={require("../assets/vector55.png")}
          />
          <Text style={[styles.canIGet, styles.howFlexBox]}>
            {" "}
            Can I get a discount an checkout ?
          </Text>
        </View>
        <View style={[styles.view2, styles.viewLayout]}>
          <Image
            style={[styles.vectorIcon2, styles.vectorIconLayout]}
            contentFit="cover"
            source={require("../assets/vector55.png")}
          />
          <Text style={[styles.howDoI, styles.howFlexBox]}>
            How do I cancel an orders ?
          </Text>
        </View>
        <View style={[styles.view3, styles.viewLayout]}>
          <Image
            style={[styles.vectorIcon5, styles.vectorIconLayout]}
            contentFit="cover"
            source={require("../assets/vector55.png")}
          />
          <Text style={[styles.howToUse, styles.howLayout]}>
            How to use Carea ?
          </Text>
        </View>
        <View style={[styles.view4, styles.view4Layout]}>
          <Image
            style={styles.vectorIcon6}
            contentFit="cover"
            source={require("../assets/vector56.png")}
          />
          <Text style={[styles.howToUse1, styles.whyITypo]}>
            How to use Carea ?
          </Text>
          <View style={styles.child} />
          <Text style={[styles.loremIpsumIs, styles.generalTypo]}>
            Lorem Ipsum is simply dummy text of the printing and typesetting
            industry. Lorem Ipsum has been the industry's standard dummy text
            ever since the 1500s,
          </Text>
        </View>
        <View style={[styles.search, styles.view4Layout]}>
          <Text style={[styles.whyI, styles.whyITypo]}>Why I</Text>
          <Image
            style={[styles.vectorIcon7, styles.vectorIconLayout1]}
            contentFit="cover"
            source={require("../assets/vector57.png")}
          />
          <Image
            style={styles.vectorIcon8}
            contentFit="cover"
            source={require("../assets/vector35.png")}
          />
        </View>
      </View>
      <View style={styles.faqButton}>
        <View style={styles.button4}>
          <Text style={[styles.text, styles.textPosition]}>Payme</Text>
        </View>
        <View style={[styles.button3, styles.buttonLayout]}>
          <Text style={styles.service}>Service</Text>
        </View>
        <View style={[styles.button2, styles.buttonLayout]}>
          <Text style={[styles.account, styles.textPosition]}>Account</Text>
        </View>
        <View style={[styles.button1, styles.button1Layout]}>
          <Text style={[styles.general, styles.generalTypo]}>General</Text>
        </View>
        <View style={[styles.faqButtonChild, styles.faqPosition]} />
        <Text style={[styles.contactUs, styles.button1Layout]}>Contact us</Text>
        <View style={[styles.faqButtonItem, styles.faqPosition]} />
        <Text style={[styles.faq, styles.howFlexBox]}>FAQ</Text>
      </View>
      <View style={styles.statusBar}>
        <View style={[styles.action, styles.timeLayout]}>
          <Text style={[styles.time, styles.timeLayout]}>9:41</Text>
        </View>
        <Image
          style={styles.containerIcon}
          contentFit="cover"
          source={require("../assets/container2.png")}
        />
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  vectorIconLayout1: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  generalFlexBox: {
    textAlign: "center",
    lineHeight: 18,
  },
  viewLayout: {
    height: 63,
    width: 380,
    backgroundColor: Color.colorTomato_200,
    borderRadius: Border.br_3xs,
    left: 1,
    position: "absolute",
  },
  vectorIconLayout: {
    left: "85.79%",
    right: "10.53%",
    height: "18.37%",
    width: "3.68%",
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    position: "absolute",
  },
  howFlexBox: {
    alignItems: "center",
    display: "flex",
    textAlign: "left",
  },
  howLayout: {
    width: 177,
    fontSize: FontSize.size_lg,
  },
  view4Layout: {
    width: 380,
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  whyITypo: {
    height: 14,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    color: Color.iOSFFFFFF,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    position: "absolute",
  },
  generalTypo: {
    fontFamily: FontFamily.poppinsRegular,
    color: Color.iOSFFFFFF,
    position: "absolute",
  },
  textPosition: {
    height: 25,
    top: 5,
    lineHeight: 30,
    fontSize: FontSize.size_mini,
    fontFamily: FontFamily.poppinsRegular,
    left: "50%",
    textAlign: "left",
    color: Color.ew,
    position: "absolute",
  },
  buttonLayout: {
    borderRadius: Border.br_xl,
    height: 38,
    top: 62,
  },
  button1Layout: {
    width: 100,
    position: "absolute",
  },
  faqPosition: {
    top: 34,
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  timeLayout: {
    width: 54,
    position: "absolute",
  },
  vectorIcon: {
    height: "30.55%",
    width: "4.27%",
    top: "42.71%",
    right: "95.65%",
    bottom: "26.74%",
    left: "0.08%",
  },
  frameIcon: {
    left: 286,
    width: 52,
    top: 0,
    overflow: "hidden",
    height: 52,
    position: "absolute",
  },
  helpCenter1: {
    bottom: 14,
    fontSize: FontSize.size_6xl,
    width: 229,
    color: Color.ew,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    position: "absolute",
    letterSpacing: 0,
    lineHeight: 18,
    left: 0,
  },
  vectorIcon1: {
    height: "41.76%",
    width: "6.68%",
    top: "27.44%",
    right: "0%",
    bottom: "30.8%",
    left: "93.32%",
  },
  peopleBusService: {
    top: 67,
    left: 32,
    width: 378,
    height: 52,
    position: "absolute",
  },
  vectorIcon2: {
    top: "43.99%",
    bottom: "37.64%",
  },
  whyCantI: {
    width: 281,
    height: 18,
    color: Color.iOSFFFFFF,
    display: "flex",
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    position: "absolute",
    fontSize: FontSize.size_lg,
    top: 23,
    left: 18,
  },
  view: {
    top: 574,
  },
  vectorIcon3: {
    top: "40.82%",
    bottom: "40.82%",
  },
  canIGet: {
    left: 15,
    letterSpacing: -0.5,
    width: 324,
    height: 18,
    color: Color.iOSFFFFFF,
    display: "flex",
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    position: "absolute",
    fontSize: FontSize.size_lg,
    top: 23,
  },
  view1: {
    top: 473,
  },
  howDoI: {
    width: 257,
    height: 18,
    color: Color.iOSFFFFFF,
    display: "flex",
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    position: "absolute",
    fontSize: FontSize.size_lg,
    top: 23,
    left: 18,
  },
  view2: {
    top: 369,
  },
  vectorIcon5: {
    top: "42.4%",
    bottom: "39.23%",
  },
  howToUse: {
    top: 22,
    height: 18,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    color: Color.iOSFFFFFF,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    position: "absolute",
    left: 18,
  },
  view3: {
    top: 265,
  },
  vectorIcon6: {
    height: "5.56%",
    top: "17.9%",
    right: "9.74%",
    bottom: "76.54%",
    left: "86.58%",
    width: "3.68%",
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    position: "absolute",
  },
  howToUse1: {
    top: 25,
    left: 21,
    width: 177,
    fontSize: FontSize.size_lg,
  },
  child: {
    marginLeft: -169.5,
    top: 57,
    borderColor: Color.iOSFFFFFF,
    borderTopWidth: 1,
    width: 339,
    height: 1,
    borderStyle: "solid",
    left: "50%",
    position: "absolute",
  },
  loremIpsumIs: {
    top: 73,
    left: 22,
    fontSize: FontSize.size_xs,
    width: 328,
    height: 67,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
  },
  view4: {
    top: 81,
    height: 162,
    backgroundColor: Color.colorTomato_200,
    width: 380,
    borderRadius: Border.br_3xs,
    left: 1,
  },
  whyI: {
    top: 21,
    left: 52,
    fontSize: FontSize.size_smi,
    width: 91,
  },
  vectorIcon7: {
    height: "37.53%",
    width: "5.53%",
    top: "34.13%",
    right: "88.95%",
    bottom: "28.35%",
    left: "5.53%",
  },
  vectorIcon8: {
    top: 18,
    right: 23,
    width: 22,
    height: 19,
    position: "absolute",
  },
  search: {
    backgroundColor: Color.ew,
    height: 56,
    width: 380,
    borderRadius: Border.br_3xs,
    left: 0,
    top: 0,
  },
  searchBar: {
    top: 267,
    left: 25,
    width: 381,
    height: 637,
    position: "absolute",
  },
  text: {
    marginLeft: -19.5,
    width: 53,
  },
  button4: {
    left: 334,
    borderTopLeftRadius: Border.br_xl,
    borderBottomLeftRadius: Border.br_xl,
    width: 75,
    height: 38,
    top: 62,
    borderWidth: 2,
    borderColor: Color.ew,
    borderStyle: "solid",
    position: "absolute",
  },
  service: {
    marginLeft: -30,
    top: 3,
    width: 56,
    height: 23,
    lineHeight: 30,
    fontSize: FontSize.size_mini,
    fontFamily: FontFamily.poppinsRegular,
    left: "50%",
    textAlign: "left",
    color: Color.ew,
    position: "absolute",
  },
  button3: {
    left: 225,
    width: 96,
    borderWidth: 2,
    borderColor: Color.ew,
    borderRadius: Border.br_xl,
    borderStyle: "solid",
    position: "absolute",
  },
  account: {
    marginLeft: -32.5,
    width: 64,
  },
  button2: {
    left: 112,
    width: 101,
    borderWidth: 2,
    borderColor: Color.ew,
    borderRadius: Border.br_xl,
    borderStyle: "solid",
    position: "absolute",
  },
  general: {
    marginLeft: -37,
    top: 10,
    fontSize: FontSize.iOSMediumBody_size,
    width: 74,
    left: "50%",
    height: 18,
    textAlign: "center",
    lineHeight: 18,
  },
  button1: {
    backgroundColor: Color.colorTomato_700,
    borderRadius: Border.br_xl,
    height: 38,
    top: 62,
    width: 100,
    left: 0,
  },
  faqButtonChild: {
    left: 189,
    backgroundColor: Color.colorDarkgray_200,
    width: 192,
    height: 2,
  },
  contactUs: {
    top: 1,
    left: 241,
    fontSize: FontSize.iOSDefaultBody_size,
    color: Color.colorDarkgray_200,
    height: 19,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    width: 100,
  },
  faqButtonItem: {
    backgroundColor: Color.colorTomato_500,
    width: 190,
    height: 4,
    left: 1,
    top: 34,
  },
  faq: {
    left: 77,
    fontSize: FontSize.size_lgi,
    width: 41,
    height: 19,
    color: Color.ew,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    position: "absolute",
    top: 0,
  },
  faqButton: {
    top: 143,
    left: 24,
    width: 409,
    height: 100,
    position: "absolute",
  },
  time: {
    fontSize: FontSize.size_mini,
    width: 54,
    textAlign: "center",
    color: Color.ew,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    lineHeight: 18,
    letterSpacing: 0,
    left: 0,
    top: 0,
  },
  action: {
    top: 14,
    left: 20,
    height: 18,
  },
  containerIcon: {
    marginTop: -5.84,
    top: "50%",
    right: 15,
    width: 67,
    height: 12,
    position: "absolute",
  },
  statusBar: {
    marginLeft: -183,
    top: 9,
    width: 375,
    height: 44,
    left: "50%",
    position: "absolute",
  },
  helpCenter: {
    backgroundColor: Color.iOSFFFFFF,
    flex: 1,
    width: "100%",
    height: 975,
  },
});

export default HelpCenter;
