import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import { FontSize, Color, FontFamily } from "../GlobalStyles";

const Privacy = () => {
  return (
    <View style={styles.privacy}>
      <View style={styles.peopleBusService}>
        <Image
          style={[styles.vectorIcon, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector68.png")}
        />
        <Text style={styles.privacyPolicy}>Privacy Policy</Text>
        <Image
          style={[styles.vectorIcon1, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector69.png")}
        />
      </View>
      <View style={styles.typesOfDataWeCollect}>
        <Text style={[styles.typesOfData, styles.yourTypo]}>
          Types of Data We Collect
        </Text>
        <Text style={[styles.text, styles.textTypo]}>1.</Text>
        <Text style={styles.loremIpsumIs}>
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry. Lorem Ipsum has been the industry's standard dummy text ever
          since the 1500s, when an unknown printer took a galley of type and
          scrambled it to make a type specimen book. It has survived not only
          five centuries, but also the leap into electronic typesetting,
          remaining essentially unchanged. It was popularised in the 1960s with
          the release of Letraset sheets.
        </Text>
      </View>
      <View style={[styles.useOfYourPersonalData, styles.yourPosition]}>
        <Text style={[styles.useOfYour, styles.yourTypo]}>
          Use of Your Personal Data
        </Text>
        <Text style={[styles.text1, styles.textTypo]}>2.</Text>
        <Text style={[styles.itIsA, styles.itIsATypo]}>
          It is a long established fact that a reader will be distracted by the
          readable content of a page when looking at its layout. The point of
          using Lorem Ipsum is that it has a more-or-less normal distribution of
          letters, as opposed to using 'Content here, content here', making it
          look like readable English. Many desktop publishing packages and web
          page editors now use Lorem Ipsum as their default model text, and a
          search for 'lorem ipsum' will uncover many web sites still in their
          infancy.
        </Text>
      </View>
      <View style={styles.disclosureOfYourPersonalDa}>
        <Text style={[styles.disclosureOfYour, styles.yourPosition]}>
          Disclosure of Your Personal Data
        </Text>
        <Text style={[styles.text, styles.textTypo]}>3.</Text>
        <Text style={[styles.contraryToPopular, styles.itIsATypo]}>
          Contrary to popular belief, Lorem Ipsum is not simply random text. It
          has roots in a piece of classical Latin literature from 45 BC, making
          it over 2000 years old. Richard McClintock, a Latin professor at
          Hampden-Sydney College in Virginia, looked up one of the more obscure
          Latin words, consectetur, from a Lorem Ipsum passage, and going
          through the cites of the word in classical literature, discovered the
          undoubtable source. Lorem Ipsum comes from sections 1.10.32 and
          1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and
          Evil) by Cicero, written in 45 BC.
        </Text>
      </View>
      <View style={styles.statusBar}>
        <View style={[styles.action, styles.timeLayout]}>
          <Text style={[styles.time, styles.timeLayout]}>9:41</Text>
        </View>
        <Image
          style={styles.containerIcon}
          contentFit="cover"
          source={require("../assets/container.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  vectorIconLayout: {
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    position: "absolute",
  },
  yourTypo: {
    fontSize: FontSize.size_lgi,
    top: 0,
    textAlign: "center",
    color: Color.ew,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    lineHeight: 18,
    letterSpacing: 0,
  },
  textTypo: {
    fontSize: FontSize.iOSDefaultTitle2_size,
    textAlign: "center",
    color: Color.ew,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    lineHeight: 18,
    letterSpacing: 0,
    left: 0,
    position: "absolute",
  },
  yourPosition: {
    left: 22,
    position: "absolute",
  },
  itIsATypo: {
    top: 38,
    textAlign: "left",
    fontFamily: FontFamily.poppinsRegular,
    lineHeight: 20,
    fontSize: FontSize.size_mini,
    color: Color.ew,
    letterSpacing: 0,
    position: "absolute",
  },
  timeLayout: {
    width: 54,
    position: "absolute",
  },
  vectorIcon: {
    height: "66.67%",
    width: "4.39%",
    top: "33.33%",
    right: "95.53%",
    bottom: "0%",
    left: "0.08%",
  },
  privacyPolicy: {
    bottom: 0,
    fontSize: FontSize.size_6xl,
    width: 229,
    textAlign: "center",
    color: Color.ew,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    lineHeight: 18,
    letterSpacing: 0,
    left: 0,
    position: "absolute",
  },
  vectorIcon1: {
    height: "91.15%",
    width: "6.86%",
    top: "0%",
    right: "0%",
    bottom: "8.85%",
    left: "93.14%",
  },
  peopleBusService: {
    top: 81,
    left: 32,
    width: 368,
    height: 24,
    position: "absolute",
  },
  typesOfData: {
    left: 17,
    position: "absolute",
  },
  text: {
    top: 1,
  },
  loremIpsumIs: {
    top: 50,
    display: "flex",
    alignItems: "center",
    height: 164,
    textAlign: "left",
    fontFamily: FontFamily.poppinsRegular,
    lineHeight: 20,
    fontSize: FontSize.size_mini,
    width: 391,
    color: Color.ew,
    left: 0,
    position: "absolute",
  },
  typesOfDataWeCollect: {
    top: 143,
    height: 214,
    width: 391,
    left: 23,
    position: "absolute",
  },
  useOfYour: {
    left: 23,
    fontSize: FontSize.size_lgi,
    position: "absolute",
  },
  text1: {
    top: 0,
    fontSize: FontSize.iOSDefaultTitle2_size,
  },
  itIsA: {
    height: 206,
    width: 389,
    left: 0,
    top: 38,
  },
  useOfYourPersonalData: {
    top: 383,
    height: 244,
    width: 389,
  },
  disclosureOfYour: {
    fontSize: FontSize.size_lgi,
    top: 0,
    textAlign: "center",
    color: Color.ew,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    lineHeight: 18,
    letterSpacing: 0,
  },
  contraryToPopular: {
    left: 1,
    width: 388,
    height: 260,
  },
  disclosureOfYourPersonalDa: {
    top: 647,
    left: 21,
    height: 298,
    width: 389,
    position: "absolute",
  },
  time: {
    fontSize: FontSize.size_mini,
    width: 54,
    top: 0,
    textAlign: "center",
    color: Color.ew,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    lineHeight: 18,
    letterSpacing: 0,
    left: 0,
  },
  action: {
    top: 14,
    left: 20,
    height: 18,
  },
  containerIcon: {
    marginTop: -5.84,
    top: "50%",
    right: 15,
    width: 67,
    height: 12,
    position: "absolute",
  },
  statusBar: {
    marginLeft: -183,
    top: 9,
    left: "50%",
    width: 375,
    height: 44,
    position: "absolute",
  },
  privacy: {
    backgroundColor: Color.iOSFFFFFF,
    flex: 1,
    width: "100%",
    height: 975,
  },
});

export default Privacy;
