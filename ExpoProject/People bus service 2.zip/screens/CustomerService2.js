import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text } from "react-native";
import { Border, FontFamily, FontSize, Color, Padding } from "../GlobalStyles";

const CustomerService2 = () => {
  return (
    <View style={styles.customerService2}>
      <View style={[styles.message, styles.messageLayout]}>
        <Image
          style={[styles.voiceBarIcon, styles.messageLayout]}
          contentFit="cover"
          source={require("../assets/voice-bar.png")}
        />
        <View style={styles.messageChild} />
        <Image
          style={styles.imageIcon}
          contentFit="cover"
          source={require("../assets/image.png")}
        />
        <Text style={[styles.message1, styles.textFlexBox]}>Message...</Text>
      </View>
      <View style={[styles.rectangleParent, styles.groupChildLayout]}>
        <View style={[styles.groupChild, styles.groupPosition1]} />
        <Text
          style={[styles.ofCourseWe, styles.canIMakeTypo]}
        >{`Of course, we will be 
waiting for your offer 👍🏻`}</Text>
        <Text style={[styles.text, styles.textTypo2]}>09:41</Text>
      </View>
      <View
        style={[styles.keyboardsiosAlphbeticKeyboa, styles.statusBarPosition]}
      >
        <View style={[styles.componentSuggestionBar, styles.componentFlexBox1]}>
          <View style={styles.componentItemFlexBox}>
            <Text style={styles.text1} numberOfLines={1}>
              Suggest
            </Text>
          </View>
          <Image
            style={styles.seperatorIcon}
            contentFit="cover"
            source={require("../assets/seperator.png")}
          />
          <View
            style={[
              styles.componentSuggestionItem1,
              styles.componentItemFlexBox,
            ]}
          >
            <Text style={styles.text1} numberOfLines={1}>
              Suggest
            </Text>
          </View>
          <Image
            style={styles.seperatorIcon}
            contentFit="cover"
            source={require("../assets/seperator1.png")}
          />
          <View
            style={[
              styles.componentSuggestionItem1,
              styles.componentItemFlexBox,
            ]}
          >
            <Text style={styles.text1} numberOfLines={1}>
              Suggest
            </Text>
          </View>
        </View>
        <View style={styles.iosAlphbeticKeyboardEngli}>
          <View
            style={[styles.componentSuggestionBar, styles.componentFlexBox1]}
          >
            <View style={styles.componentItemFlexBox}>
              <Text style={styles.text1} numberOfLines={1}>
                Suggest
              </Text>
            </View>
            <Image
              style={styles.seperatorIcon}
              contentFit="cover"
              source={require("../assets/seperator.png")}
            />
            <View
              style={[
                styles.componentSuggestionItem1,
                styles.componentItemFlexBox,
              ]}
            >
              <Text style={styles.text1} numberOfLines={1}>
                Suggest
              </Text>
            </View>
            <Image
              style={styles.seperatorIcon}
              contentFit="cover"
              source={require("../assets/seperator1.png")}
            />
            <View
              style={[
                styles.componentSuggestionItem1,
                styles.componentItemFlexBox,
              ]}
            >
              <Text style={styles.text1} numberOfLines={1}>
                Suggest
              </Text>
            </View>
          </View>
          <View style={[styles.keysLayoutAlphabeticEng, styles.componentBg]}>
            <View style={styles.rowAlphabetic}>
              <View style={styles.componentShadowBox3}>
                <Text style={[styles.text7, styles.textTypo1]}>q</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text7, styles.textTypo1]}>w</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text7, styles.textTypo1]}>e</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text7, styles.textTypo1]}>r</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text7, styles.textTypo1]}>t</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text7, styles.textTypo1]}>y</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text7, styles.textTypo1]}>u</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text7, styles.textTypo1]}>i</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text7, styles.textTypo1]}>o</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text7, styles.textTypo1]}>p</Text>
              </View>
            </View>
            <View style={[styles.rowAlphabetic1, styles.rowFlexBox]}>
              <View style={styles.componentShadowBox3}>
                <Text style={[styles.text7, styles.textTypo1]}>a</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text7, styles.textTypo1]}>s</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text7, styles.textTypo1]}>d</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text7, styles.textTypo1]}>f</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text7, styles.textTypo1]}>g</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text7, styles.textTypo1]}>h</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text7, styles.textTypo1]}>j</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text7, styles.textTypo1]}>k</Text>
              </View>
              <View style={styles.componentShadowBox2}>
                <Text style={[styles.text7, styles.textTypo1]}>l</Text>
              </View>
            </View>
            <View style={styles.rowFlexBox}>
              <View style={[styles.componentKey19, styles.componentShadowBox1]}>
                <Text style={[styles.text26, styles.spaceTypo]}>􀆝</Text>
              </View>
              <View
                style={[styles.rowAlphabetic2, styles.rowAlphabetic2SpaceBlock]}
              >
                <View style={styles.componentShadowBox3}>
                  <Text style={[styles.text7, styles.textTypo1]}>z</Text>
                </View>
                <View style={styles.componentShadowBox2}>
                  <Text style={[styles.text7, styles.textTypo1]}>x</Text>
                </View>
                <View style={styles.componentShadowBox2}>
                  <Text style={[styles.text7, styles.textTypo1]}>c</Text>
                </View>
                <View style={styles.componentShadowBox2}>
                  <Text style={[styles.text7, styles.textTypo1]}>v</Text>
                </View>
                <View style={styles.componentShadowBox2}>
                  <Text style={[styles.text7, styles.textTypo1]}>b</Text>
                </View>
                <View style={styles.componentShadowBox2}>
                  <Text style={[styles.text7, styles.textTypo1]}>n</Text>
                </View>
                <View style={styles.componentShadowBox2}>
                  <Text style={[styles.text7, styles.textTypo1]}>m</Text>
                </View>
              </View>
              <View style={[styles.componentKey27, styles.componentFlexBox]}>
                <Text style={[styles.text26, styles.spaceTypo]}>􀆛</Text>
              </View>
            </View>
            <View style={styles.rowFlexBox}>
              <View style={[styles.componentKey28, styles.componentFlexBox]}>
                <Text style={[styles.text26, styles.spaceTypo]}>123</Text>
              </View>
              <View style={[styles.componentKey29, styles.componentShadowBox]}>
                <Text style={styles.spaceTypo}>space</Text>
              </View>
              <View style={[styles.componentKey30, styles.componentShadowBox]}>
                <Text style={[styles.text26, styles.spaceTypo]}>Go</Text>
              </View>
            </View>
          </View>
          <View style={[styles.componentHomeIndicatorSec, styles.componentBg]}>
            <View style={styles.keys}>
              <View style={styles.componentKey31}>
                <Text style={[styles.text37, styles.textTypo1]}>􀎸</Text>
              </View>
              <View style={styles.componentKey31}>
                <Text style={[styles.text37, styles.textTypo1]}>􀊰</Text>
              </View>
            </View>
            <View
              style={[styles.componentHomeIndicator, styles.componentFlexBox1]}
            >
              <View style={styles.indicator} />
            </View>
          </View>
        </View>
      </View>
      <View style={[styles.rectangleGroup, styles.groupLayout]}>
        <View style={[styles.groupItem, styles.groupPosition]} />
        <Text
          style={[styles.thankYouI, styles.textClr]}
        >{`Thank you! I will make an
offer right now 😍
😍
`}</Text>
        <Text style={[styles.text39, styles.textTypo]}>09:41</Text>
      </View>
      <View style={[styles.rectangleContainer, styles.groupInnerLayout]}>
        <View style={[styles.groupInner, styles.groupInnerLayout]} />
        <Text style={[styles.text40, styles.textClr]}>09:41</Text>
        <Text
          style={[styles.ofCourseYou, styles.textClr]}
        >{`Of course you can, please
make an offer. If the price
is still suitable. then we will
accept 😁
😁
`}</Text>
      </View>
      <View style={[styles.groupView, styles.viewLayout]}>
        <View style={[styles.rectangleView, styles.viewLayout]} />
        <Text style={[styles.text41, styles.textTypo]}>09:41</Text>
        <Text style={[styles.helloGoodMorning, styles.textClr]}>
          Hello, good morning
        </Text>
      </View>
      <View style={[styles.rectangleParent1, styles.groupChild1Layout]}>
        <View style={[styles.groupChild1, styles.groupChild1Layout]} />
        <Text style={[styles.canIMake, styles.textClr]}>
          Can I make an offer to the price? I think the current price is too
          high 😅 😅
        </Text>
        <Text style={[styles.text42, styles.textClr]}>09:41</Text>
      </View>
      <View style={[styles.rectangleParent2, styles.groupLayout]}>
        <View style={[styles.groupItem, styles.groupPosition]} />
        <Text style={[styles.thankYouI, styles.textClr]}>
          Hi Good Morning, I want to buy a BMW M5 Series
        </Text>
        <Text style={[styles.text43, styles.textClr]}>09:41</Text>
      </View>
      <View style={[styles.today, styles.todayLayout]}>
        <View style={[styles.todayChild, styles.todayLayout]} />
        <Text style={[styles.today1, styles.textFlexBox]}>Today</Text>
      </View>
      <View style={styles.peopleBusService}>
        <Image
          style={[styles.vectorIcon, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector78.png")}
        />
        <Image
          style={styles.frameIcon}
          contentFit="cover"
          source={require("../assets/frame2.png")}
        />
        <Text style={[styles.peopleBusService1, styles.timeTypo]}>
          People Bus Service
        </Text>
        <Image
          style={[styles.vectorIcon1, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector13.png")}
        />
      </View>
      <View style={[styles.statusBar, styles.statusBarPosition]}>
        <View style={[styles.action, styles.timeLayout]}>
          <Text style={[styles.time, styles.timeLayout]}>9:41</Text>
        </View>
        <Image
          style={styles.containerIcon}
          contentFit="cover"
          source={require("../assets/container2.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  messageLayout: {
    height: 56,
    position: "absolute",
  },
  textFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  groupChildLayout: {
    height: 68,
    width: 284,
    position: "absolute",
  },
  groupPosition1: {
    borderBottomLeftRadius: Border.br_mini,
    borderBottomRightRadius: Border.br_mini,
    borderTopRightRadius: Border.br_mini,
    left: 0,
    top: 0,
  },
  canIMakeTypo: {
    width: 213,
    alignItems: "center",
    display: "flex",
    top: 12,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_mini,
  },
  textTypo2: {
    left: 233,
    fontFamily: FontFamily.poppinsLight,
    fontWeight: "300",
    fontSize: FontSize.size_smi,
  },
  statusBarPosition: {
    left: "50%",
    position: "absolute",
  },
  componentFlexBox1: {
    justifyContent: "center",
    alignItems: "center",
  },
  componentItemFlexBox: {
    height: 34,
    borderRadius: Border.br_8xs_6,
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  componentBg: {
    backgroundColor: Color.iOSAlfaCCCED376,
    alignSelf: "stretch",
  },
  textTypo1: {
    fontFamily: FontFamily.iOSDefaultTitle2,
    textAlign: "center",
  },
  rowFlexBox: {
    marginTop: 12,
    flexDirection: "row",
    alignSelf: "stretch",
  },
  componentShadowBox1: {
    padding: Padding.p_2xs,
    height: 42,
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "#898a8d",
    borderRadius: Border.br_8xs_6,
    overflow: "hidden",
  },
  spaceTypo: {
    lineHeight: 21,
    fontSize: FontSize.iOSMediumBody_size,
    textAlign: "center",
    fontFamily: FontFamily.iOSMediumBody,
    color: Color.ew,
    flex: 1,
  },
  rowAlphabetic2SpaceBlock: {
    marginLeft: 1,
    flexDirection: "row",
  },
  componentFlexBox: {
    backgroundColor: Color.iOSADB3BC,
    justifyContent: "center",
    alignItems: "center",
  },
  componentShadowBox: {
    marginLeft: 6,
    padding: Padding.p_2xs,
    height: 42,
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "#898a8d",
    borderRadius: Border.br_8xs_6,
    flexDirection: "row",
    overflow: "hidden",
  },
  groupLayout: {
    width: 283,
    height: 68,
    position: "absolute",
  },
  groupPosition: {
    borderTopLeftRadius: Border.br_mini,
    borderBottomLeftRadius: Border.br_mini,
    borderBottomRightRadius: Border.br_mini,
    left: 0,
    top: 0,
  },
  textClr: {
    color: Color.iOSFFFFFF,
    textAlign: "left",
    position: "absolute",
  },
  textTypo: {
    left: 232,
    color: Color.iOSFFFFFF,
    textAlign: "left",
    fontFamily: FontFamily.poppinsLight,
    fontWeight: "300",
    fontSize: FontSize.size_smi,
    position: "absolute",
  },
  groupInnerLayout: {
    height: 110,
    width: 282,
    position: "absolute",
  },
  viewLayout: {
    height: 48,
    width: 284,
    position: "absolute",
  },
  groupChild1Layout: {
    height: 90,
    width: 283,
    position: "absolute",
  },
  todayLayout: {
    width: 50,
    height: 24,
    position: "absolute",
  },
  vectorIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  timeTypo: {
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    lineHeight: 18,
    letterSpacing: 0,
    textAlign: "center",
    color: Color.ew,
    left: 0,
  },
  timeLayout: {
    width: 54,
    position: "absolute",
  },
  voiceBarIcon: {
    left: 325,
    width: 56,
    top: 0,
  },
  messageChild: {
    top: 1,
    borderRadius: Border.br_mini,
    backgroundColor: Color.colorGray_600,
    width: 314,
    height: 55,
    opacity: 0.1,
    left: 0,
    position: "absolute",
  },
  imageIcon: {
    top: 20,
    left: 275,
    width: 16,
    height: 16,
    position: "absolute",
  },
  message1: {
    top: 18,
    left: 22,
    color: Color.colorDarkgray_100,
    fontFamily: FontFamily.poppinsLight,
    fontWeight: "300",
    fontSize: FontSize.size_smi,
  },
  message: {
    top: 822,
    left: 25,
    width: 381,
  },
  groupChild: {
    backgroundColor: Color.colorWhitesmoke_100,
    height: 68,
    width: 284,
    position: "absolute",
  },
  ofCourseWe: {
    color: Color.ew,
    left: 20,
    textAlign: "left",
    position: "absolute",
  },
  text: {
    color: Color.colorWhitesmoke_100,
    top: 36,
    textAlign: "left",
    position: "absolute",
  },
  rectangleParent: {
    top: 666,
    left: 26,
  },
  text1: {
    fontSize: FontSize.iOSDefaultBody_size,
    lineHeight: 20,
    color: Color.iOS3A3B3D,
    height: 20,
    textAlign: "center",
    fontFamily: FontFamily.iOSMediumBody,
    overflow: "hidden",
    flex: 1,
  },
  seperatorIcon: {
    width: 0,
    marginLeft: 2,
    height: 24,
  },
  componentSuggestionItem1: {
    marginLeft: 2,
  },
  componentSuggestionBar: {
    paddingHorizontal: Padding.p_12xs,
    paddingTop: Padding.p_3xs,
    display: "none",
    flexDirection: "row",
    overflow: "hidden",
    backgroundColor: Color.iOSAlfaCCCED376,
    alignSelf: "stretch",
  },
  text7: {
    fontSize: FontSize.iOSDefaultTitle2_size,
    lineHeight: 28,
    color: Color.ew,
    flex: 1,
  },
  componentShadowBox3: {
    padding: Padding.p_6xs,
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "#898a8d",
    borderRadius: Border.br_8xs_6,
    justifyContent: "center",
    flexDirection: "row",
    overflow: "hidden",
    alignItems: "center",
    flex: 1,
    backgroundColor: Color.iOSFFFFFF,
  },
  componentShadowBox2: {
    marginLeft: 5,
    padding: Padding.p_6xs,
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "#898a8d",
    borderRadius: Border.br_8xs_6,
    justifyContent: "center",
    flexDirection: "row",
    overflow: "hidden",
    alignItems: "center",
    flex: 1,
    backgroundColor: Color.iOSFFFFFF,
  },
  rowAlphabetic: {
    flexDirection: "row",
    alignSelf: "stretch",
  },
  rowAlphabetic1: {
    paddingHorizontal: Padding.p_lg,
    paddingVertical: 0,
  },
  text26: {
    height: 20,
  },
  componentKey19: {
    width: 42,
    padding: Padding.p_2xs,
    height: 42,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    backgroundColor: Color.iOSFFFFFF,
  },
  rowAlphabetic2: {
    paddingHorizontal: Padding.p_smi,
    paddingVertical: 0,
    flex: 1,
  },
  componentKey27: {
    marginLeft: 1,
    flexDirection: "row",
    padding: Padding.p_2xs,
    height: 42,
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "#898a8d",
    borderRadius: Border.br_8xs_6,
    overflow: "hidden",
    width: 42,
  },
  componentKey28: {
    width: 87,
    padding: Padding.p_2xs,
    height: 42,
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "#898a8d",
    borderRadius: Border.br_8xs_6,
    overflow: "hidden",
    flexDirection: "row",
  },
  componentKey29: {
    flex: 1,
    backgroundColor: Color.iOSFFFFFF,
  },
  componentKey30: {
    width: 88,
    backgroundColor: Color.iOSADB3BC,
    justifyContent: "center",
    alignItems: "center",
  },
  keysLayoutAlphabeticEng: {
    paddingHorizontal: Padding.p_10xs,
    paddingVertical: Padding.p_5xs,
  },
  text37: {
    fontSize: FontSize.size_7xl,
    color: Color.iOS50555C,
  },
  componentKey31: {
    width: 47,
    height: 47,
    padding: Padding.p_5xs,
    borderRadius: Border.br_8xs_6,
    justifyContent: "center",
    flexDirection: "row",
    overflow: "hidden",
    alignItems: "center",
  },
  keys: {
    justifyContent: "space-between",
    paddingHorizontal: Padding.p_xl,
    paddingTop: Padding.p_4xs,
    flexDirection: "row",
    alignSelf: "stretch",
  },
  indicator: {
    width: 134,
    height: 5,
    backgroundColor: Color.ew,
    borderRadius: Border.br_8xs,
  },
  componentHomeIndicator: {
    paddingHorizontal: Padding.p_101xl,
    paddingTop: Padding.p_12xs,
    paddingBottom: Padding.p_4xs,
    alignSelf: "stretch",
  },
  componentHomeIndicatorSec: {
    justifyContent: "flex-end",
  },
  iosAlphbeticKeyboardEngli: {
    width: 428,
  },
  keyboardsiosAlphbeticKeyboa: {
    marginLeft: -214,
    bottom: 0,
    width: 428,
  },
  groupItem: {
    backgroundColor: Color.colorTomato_400,
    width: 283,
    height: 68,
    position: "absolute",
  },
  thankYouI: {
    top: 11,
    color: Color.iOSFFFFFF,
    width: 213,
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_mini,
    left: 20,
  },
  text39: {
    top: 36,
  },
  rectangleGroup: {
    top: 574,
    left: 124,
  },
  groupInner: {
    backgroundColor: Color.ew,
    borderBottomLeftRadius: Border.br_mini,
    borderBottomRightRadius: Border.br_mini,
    borderTopRightRadius: Border.br_mini,
    left: 0,
    top: 0,
  },
  text40: {
    top: 79,
    left: 231,
    fontFamily: FontFamily.poppinsLight,
    fontWeight: "300",
    fontSize: FontSize.size_smi,
  },
  ofCourseYou: {
    left: 18,
    top: 11,
    color: Color.iOSFFFFFF,
    width: 213,
    alignItems: "center",
    display: "flex",
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_mini,
  },
  rectangleContainer: {
    top: 439,
    left: 27,
  },
  rectangleView: {
    backgroundColor: Color.ew,
    borderBottomLeftRadius: Border.br_mini,
    borderBottomRightRadius: Border.br_mini,
    borderTopRightRadius: Border.br_mini,
    left: 0,
    top: 0,
  },
  text41: {
    top: 15,
  },
  helloGoodMorning: {
    top: 13,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.iOSFFFFFF,
    fontSize: FontSize.size_mini,
    left: 20,
  },
  groupView: {
    top: 379,
    left: 26,
  },
  groupChild1: {
    backgroundColor: Color.colorTomato_600,
    borderTopLeftRadius: Border.br_mini,
    borderBottomLeftRadius: Border.br_mini,
    borderBottomRightRadius: Border.br_mini,
    left: 0,
    top: 0,
  },
  canIMake: {
    left: 19,
    width: 213,
    alignItems: "center",
    display: "flex",
    top: 12,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_mini,
  },
  text42: {
    top: 58,
    left: 233,
    fontFamily: FontFamily.poppinsLight,
    fontWeight: "300",
    fontSize: FontSize.size_smi,
  },
  rectangleParent1: {
    top: 266,
    left: 123,
  },
  text43: {
    left: 233,
    fontFamily: FontFamily.poppinsLight,
    fontWeight: "300",
    fontSize: FontSize.size_smi,
    top: 36,
  },
  rectangleParent2: {
    top: 188,
    left: 123,
  },
  todayChild: {
    backgroundColor: Color.colorWhitesmoke_200,
    borderRadius: Border.br_8xs,
    left: 0,
    top: 0,
  },
  today1: {
    top: 6,
    left: 11,
    fontSize: FontSize.size_4xs,
    color: Color.ew,
    fontFamily: FontFamily.poppinsLight,
    fontWeight: "300",
  },
  today: {
    top: 140,
    left: 191,
  },
  vectorIcon: {
    height: "30.55%",
    width: "4.28%",
    top: "35.07%",
    right: "95.72%",
    bottom: "34.38%",
    left: "0%",
  },
  frameIcon: {
    left: 286,
    width: 52,
    height: 52,
    overflow: "hidden",
    top: 0,
    position: "absolute",
  },
  peopleBusService1: {
    bottom: 18,
    fontSize: FontSize.size_6xl,
    width: 292,
    position: "absolute",
  },
  vectorIcon1: {
    height: "41.76%",
    width: "6.68%",
    top: "27.44%",
    right: "0%",
    bottom: "30.8%",
    left: "93.32%",
  },
  peopleBusService: {
    height: "5.37%",
    width: "87.38%",
    top: "7.24%",
    right: "5.14%",
    bottom: "87.38%",
    left: "7.48%",
    position: "absolute",
  },
  time: {
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    lineHeight: 18,
    letterSpacing: 0,
    textAlign: "center",
    color: Color.ew,
    left: 0,
    fontSize: FontSize.size_mini,
    width: 54,
    top: 0,
  },
  action: {
    top: 14,
    height: 18,
    left: 20,
  },
  containerIcon: {
    marginTop: -5.84,
    top: "50%",
    right: 15,
    width: 67,
    height: 12,
    position: "absolute",
  },
  statusBar: {
    marginLeft: -183,
    top: 9,
    width: 375,
    height: 44,
  },
  customerService2: {
    width: "100%",
    height: 975,
    flex: 1,
    backgroundColor: Color.iOSFFFFFF,
  },
});

export default CustomerService2;
