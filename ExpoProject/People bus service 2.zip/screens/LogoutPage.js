import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const LogoutPage = () => {
  return (
    <View style={styles.logoutPage}>
      <View style={[styles.userName, styles.parentLayout1]}>
        <View style={[styles.vectorParent, styles.parentLayout]}>
          <Image
            style={[styles.vectorIcon, styles.vectorIconLayout]}
            contentFit="cover"
            source={require("../assets/vector39.png")}
          />
          <Image
            style={[styles.vectorIcon1, styles.vectorIconPosition4]}
            contentFit="cover"
            source={require("../assets/vector40.png")}
          />
          <Text style={[styles.logout, styles.logoutTypo]}>Logout</Text>
        </View>
        <View style={[styles.helpCenterParent, styles.parentLayout1]}>
          <Text style={[styles.helpCenter, styles.logoutTypo]}>
            Help Center
          </Text>
          <Image
            style={[styles.vectorIcon2, styles.vectorIconPosition2]}
            contentFit="cover"
            source={require("../assets/vector41.png")}
          />
          <Image
            style={[styles.vectorIcon3, styles.vectorIconPosition]}
            contentFit="cover"
            source={require("../assets/vector39.png")}
          />
        </View>
        <View style={[styles.privacyPolicyParent, styles.solid1ParentLayout]}>
          <Text style={[styles.privacyPolicy, styles.logoutTypo]}>
            Privacy Policy
          </Text>
          <Image
            style={[styles.vectorIcon4, styles.vectorIconPosition1]}
            contentFit="cover"
            source={require("../assets/vector39.png")}
          />
          <Image
            style={[styles.vectorIcon5, styles.vectorIconPosition2]}
            contentFit="cover"
            source={require("../assets/vector42.png")}
          />
        </View>
        <View style={styles.vectorGroup}>
          <Image
            style={[styles.vectorIcon6, styles.vectorIconPosition4]}
            contentFit="cover"
            source={require("../assets/vector43.png")}
          />
          <Text style={[styles.helpCenter, styles.logoutTypo]}>Dark Mode</Text>
        </View>
        <View style={[styles.languageIcon1Parent, styles.parentLayout1]}>
          <Image
            style={styles.languageIcon1}
            contentFit="cover"
            source={require("../assets/languageicon-1.png")}
          />
          <Text style={[styles.languages, styles.logoutTypo]}>Languages</Text>
          <Text style={[styles.englishUs, styles.logoutTypo]}>
            English (US)
          </Text>
          <Image
            style={[styles.vectorIcon7, styles.vectorIconPosition]}
            contentFit="cover"
            source={require("../assets/vector39.png")}
          />
        </View>
        <View style={[styles.vectorContainer, styles.parentLayout1]}>
          <Image
            style={[styles.vectorIcon8, styles.vectorIconPosition3]}
            contentFit="cover"
            source={require("../assets/vector44.png")}
          />
          <Text style={[styles.helpCenter, styles.logoutTypo]}>Security</Text>
          <Image
            style={[styles.vectorIcon3, styles.vectorIconPosition]}
            contentFit="cover"
            source={require("../assets/vector39.png")}
          />
        </View>
        <View style={[styles.frameView, styles.parentLayout]}>
          <Image
            style={[styles.vectorIcon10, styles.vectorIconPosition4]}
            contentFit="cover"
            source={require("../assets/vector45.png")}
          />
          <Text style={[styles.payment, styles.logoutTypo]}>Payment</Text>
          <Image
            style={[styles.vectorIcon4, styles.vectorIconPosition1]}
            contentFit="cover"
            source={require("../assets/vector39.png")}
          />
        </View>
        <View style={[styles.bellSolid1Parent, styles.solid1ParentLayout]}>
          <Image
            style={[styles.bellSolid1Icon, styles.solid1IconLayout]}
            contentFit="cover"
            source={require("../assets/bellsolid-1.png")}
          />
          <Text style={[styles.privacyPolicy, styles.logoutTypo]}>
            Notification
          </Text>
          <Image
            style={[styles.vectorIcon4, styles.vectorIconPosition1]}
            contentFit="cover"
            source={require("../assets/vector39.png")}
          />
        </View>
        <View
          style={[styles.locationDotSolid1Parent, styles.solid1ParentLayout]}
        >
          <Image
            style={[styles.locationDotSolid1Icon, styles.solid1IconPosition]}
            contentFit="cover"
            source={require("../assets/locationdotsolid-1.png")}
          />
          <Text style={[styles.privacyPolicy, styles.logoutTypo]}>Address</Text>
          <Image
            style={[styles.vectorIcon13, styles.vectorIconPosition1]}
            contentFit="cover"
            source={require("../assets/vector39.png")}
          />
        </View>
        <View style={[styles.userSolid1Parent, styles.parentLayout]}>
          <Image
            style={[styles.userSolid1Icon, styles.solid1IconPosition]}
            contentFit="cover"
            source={require("../assets/usersolid-1.png")}
          />
          <Text
            style={[styles.payment, styles.logoutTypo]}
          >{`Edit Profile `}</Text>
          <Image
            style={[styles.vectorIcon13, styles.vectorIconPosition1]}
            contentFit="cover"
            source={require("../assets/vector39.png")}
          />
        </View>
        <View style={[styles.userNameChild, styles.userPosition]} />
        <Text style={[styles.haha828087gmailcom, styles.userPosition]}>
          Haha828087@gmail.com
        </Text>
        <Image
          style={[styles.userNameItem, styles.userPosition]}
          contentFit="cover"
          source={require("../assets/group-6952.png")}
        />
      </View>
      <View style={[styles.logoutPageChild, styles.logoutPosition1]} />
      <View style={[styles.pic, styles.picLayout]}>
        <Image
          style={[styles.picChild, styles.picLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-3131.png")}
        />
        <Image
          style={[styles.vectorIcon15, styles.vectorIcon15Layout]}
          contentFit="cover"
          source={require("../assets/vector46.png")}
        />
        <Text style={styles.text}>+1 111467378399</Text>
        <Text style={[styles.ose, styles.oseTypo]}>Lena Rose</Text>
      </View>
      <View style={styles.profile}>
        <Image
          style={[styles.vectorIcon16, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector13.png")}
        />
        <Text style={[styles.profile1, styles.oseTypo]}>Profile</Text>
        <Image
          style={[styles.vectorIcon17, styles.vectorIconPosition4]}
          contentFit="cover"
          source={require("../assets/vector38.png")}
        />
      </View>
      <View style={styles.statusBar}>
        <View style={[styles.action, styles.timeLayout]}>
          <Text style={[styles.time, styles.timeLayout]}>9:41</Text>
        </View>
        <Image
          style={[styles.containerIcon, styles.logout1Position]}
          contentFit="cover"
          source={require("../assets/container2.png")}
        />
      </View>
      <View style={[styles.logoutRectangleWrapper, styles.logoutPosition]}>
        <View style={[styles.logoutRectangle, styles.logoutPosition]}>
          <View
            style={[styles.logoutRectangleChild, styles.vectorIcon15Layout]}
          />
          <Text style={[styles.logout1, styles.logout1Position]}> Logout</Text>
          <View style={[styles.logoutRectangleItem, styles.logoutPosition1]} />
          <Text style={styles.areYouSure}>
            Are you sure you want to log out ?
          </Text>
          <View style={[styles.button, styles.buttonLayout]}>
            <Text style={[styles.cancel, styles.cancelPosition]}>Cancel</Text>
          </View>
          <View style={[styles.button1, styles.buttonLayout]}>
            <LinearGradient
              style={[styles.buttonChild, styles.buttonLayout]}
              locations={[0, 1]}
              colors={["rgba(240, 0, 0, 0.96)", "#dc281e"]}
            />
            <Text style={[styles.yesLogout, styles.cancelPosition]}>
              Yes, Logout
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  parentLayout1: {
    width: 371,
    position: "absolute",
  },
  parentLayout: {
    width: 370,
    left: 1,
    height: 24,
    position: "absolute",
  },
  vectorIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  vectorIconPosition4: {
    left: "0%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  logoutTypo: {
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    fontSize: FontSize.iOSMediumBody_size,
    textAlign: "left",
  },
  vectorIconPosition2: {
    bottom: "12.5%",
    left: "0%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  vectorIconPosition: {
    left: "98.09%",
    width: "1.91%",
    maxHeight: "100%",
    maxWidth: "100%",
    right: "0%",
    position: "absolute",
    overflow: "hidden",
  },
  solid1ParentLayout: {
    width: 369,
    left: 2,
    height: 24,
    position: "absolute",
  },
  vectorIconPosition1: {
    bottom: "18.1%",
    top: "16.77%",
  },
  vectorIconPosition3: {
    right: "94.61%",
    top: "4.17%",
    width: "5.39%",
  },
  solid1IconLayout: {
    width: 16,
    top: 2,
  },
  solid1IconPosition: {
    height: 20,
    left: 0,
    position: "absolute",
    overflow: "hidden",
  },
  userPosition: {
    display: "none",
    position: "absolute",
  },
  logoutPosition1: {
    height: 1,
    borderTopWidth: 1,
    borderColor: Color.ew,
    left: "50%",
    borderStyle: "solid",
    position: "absolute",
  },
  picLayout: {
    width: 146,
    position: "absolute",
  },
  vectorIcon15Layout: {
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  oseTypo: {
    color: Color.colorGray_400,
    fontSize: FontSize.size_7xl,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    textAlign: "left",
    position: "absolute",
  },
  timeLayout: {
    width: 54,
    position: "absolute",
  },
  logout1Position: {
    top: "50%",
    position: "absolute",
  },
  logoutPosition: {
    width: 428,
    left: 0,
    position: "absolute",
  },
  buttonLayout: {
    height: 54,
    width: 168,
    position: "absolute",
  },
  cancelPosition: {
    color: Color.iOSFFFFFF,
    marginTop: -14,
    fontSize: FontSize.size_lg,
    top: "50%",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    left: "50%",
    textAlign: "left",
    position: "absolute",
  },
  vectorIcon: {
    top: "20.94%",
    bottom: "13.94%",
    left: "98.08%",
    width: "1.92%",
    maxHeight: "100%",
    maxWidth: "100%",
    right: "0%",
    position: "absolute",
    height: "65.12%",
  },
  vectorIcon1: {
    height: "75%",
    width: "5.4%",
    right: "94.6%",
    bottom: "16.67%",
    left: "0%",
    top: "8.33%",
  },
  logout: {
    color: Color.colorTomato_100,
    textAlign: "left",
    left: 38,
    fontWeight: "700",
    fontSize: FontSize.iOSMediumBody_size,
    position: "absolute",
    top: 0,
  },
  vectorParent: {
    top: 405,
    height: 24,
  },
  helpCenter: {
    color: Color.ew,
    textAlign: "left",
    left: 38,
    fontWeight: "700",
    fontSize: FontSize.iOSMediumBody_size,
    position: "absolute",
    top: 0,
  },
  vectorIcon2: {
    height: "83.33%",
    right: "94.61%",
    top: "4.17%",
    width: "5.39%",
  },
  vectorIcon3: {
    bottom: "18.1%",
    top: "16.77%",
    height: "65.12%",
  },
  helpCenterParent: {
    top: 360,
    left: 0,
    height: 24,
  },
  privacyPolicy: {
    left: 36,
    color: Color.ew,
    textAlign: "left",
    top: 0,
    position: "absolute",
  },
  vectorIcon4: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    left: "98.08%",
    width: "1.92%",
    right: "0%",
    position: "absolute",
    height: "65.12%",
  },
  vectorIcon5: {
    height: "79.17%",
    width: "4.33%",
    right: "95.67%",
    top: "8.33%",
  },
  privacyPolicyParent: {
    top: 315,
  },
  vectorIcon6: {
    height: "61.98%",
    width: "16.54%",
    top: "16.93%",
    right: "83.46%",
    bottom: "21.09%",
  },
  vectorGroup: {
    top: 270,
    width: 127,
    left: 0,
    height: 24,
    position: "absolute",
  },
  languageIcon1: {
    top: 4,
    width: 20,
    height: 17,
    left: 0,
    position: "absolute",
    overflow: "hidden",
  },
  languages: {
    top: 1,
    color: Color.ew,
    textAlign: "left",
    left: 38,
    fontWeight: "700",
    fontSize: FontSize.iOSMediumBody_size,
    position: "absolute",
  },
  englishUs: {
    left: 243,
    color: Color.ew,
    textAlign: "left",
    top: 0,
    position: "absolute",
  },
  vectorIcon7: {
    height: "62.52%",
    top: "20.1%",
    bottom: "17.38%",
  },
  languageIcon1Parent: {
    top: 224,
    height: 25,
    left: 0,
  },
  vectorIcon8: {
    height: "95.83%",
    bottom: "0%",
    left: "0%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  vectorContainer: {
    top: 180,
    left: 0,
    height: 24,
  },
  vectorIcon10: {
    height: "66.67%",
    width: "5.13%",
    top: "16.67%",
    right: "94.87%",
    bottom: "16.67%",
    left: "0%",
  },
  payment: {
    left: 37,
    color: Color.ew,
    textAlign: "left",
    top: 0,
    position: "absolute",
  },
  frameView: {
    top: 135,
    height: 24,
  },
  bellSolid1Icon: {
    height: 19,
    left: 0,
    position: "absolute",
    overflow: "hidden",
  },
  bellSolid1Parent: {
    top: 90,
  },
  locationDotSolid1Icon: {
    width: 16,
    top: 2,
  },
  vectorIcon13: {
    height: "65.13%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    left: "98.08%",
    width: "1.92%",
    right: "0%",
    position: "absolute",
  },
  locationDotSolid1Parent: {
    top: 45,
  },
  userSolid1Icon: {
    width: 18,
    top: 1,
  },
  userSolid1Parent: {
    top: 0,
    height: 24,
  },
  userNameChild: {
    top: 102,
    left: 10,
    borderColor: Color.colorWhitesmoke_300,
    borderWidth: 1,
    width: 355,
    height: 53,
    borderStyle: "solid",
    display: "none",
    borderRadius: Border.br_17xl,
  },
  haha828087gmailcom: {
    top: 116,
    left: 65,
    width: 212,
    color: Color.ew,
    textAlign: "left",
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    fontSize: FontSize.iOSMediumBody_size,
    height: 24,
  },
  userNameItem: {
    top: 117,
    left: 30,
    width: 22,
    height: 22,
  },
  userName: {
    top: 366,
    height: 429,
    left: 26,
  },
  logoutPageChild: {
    marginLeft: -187.5,
    top: 345,
    width: 374,
  },
  picChild: {
    height: 146,
    left: 0,
    top: 0,
  },
  vectorIcon15: {
    height: "13.79%",
    width: "19.18%",
    top: "53.69%",
    right: "4.11%",
    bottom: "32.51%",
    left: "76.71%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  text: {
    top: 182,
    left: 17,
    fontSize: FontSize.size_sm,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    color: Color.ew,
    textAlign: "left",
    position: "absolute",
  },
  ose: {
    top: 140,
    left: 7,
    width: 133,
  },
  pic: {
    top: 123,
    left: 141,
    height: 203,
  },
  vectorIcon16: {
    height: "56.09%",
    width: "6.63%",
    top: "17.95%",
    bottom: "25.96%",
    left: "93.37%",
    right: "0%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
  },
  profile1: {
    left: 29,
    width: 86,
    top: 0,
  },
  vectorIcon17: {
    height: "40.08%",
    width: "2.68%",
    top: "33.33%",
    right: "97.32%",
    bottom: "26.59%",
  },
  profile: {
    top: 74,
    width: 377,
    height: 39,
    left: 26,
    position: "absolute",
  },
  time: {
    fontSize: FontSize.size_mini,
    letterSpacing: 0,
    lineHeight: 18,
    textAlign: "center",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    color: Color.ew,
    left: 0,
    top: 0,
  },
  action: {
    top: 14,
    left: 20,
    height: 18,
  },
  containerIcon: {
    marginTop: -5.84,
    right: 15,
    width: 67,
    height: 12,
  },
  statusBar: {
    marginLeft: -183,
    top: 9,
    width: 375,
    height: 44,
    left: "50%",
    position: "absolute",
  },
  logoutRectangleChild: {
    marginLeft: -21,
    top: 5,
    width: 41,
    height: 3,
    backgroundColor: Color.ew,
    left: "50%",
  },
  logout1: {
    marginTop: -103,
    marginLeft: -47,
    fontSize: FontSize.iOSDefaultTitle2_size,
    color: "#f00b0b",
    width: 94,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    left: "50%",
    textAlign: "left",
  },
  logoutRectangleItem: {
    marginLeft: -195.5,
    top: 83,
    width: 391,
    backgroundColor: Color.ew,
  },
  areYouSure: {
    marginTop: -21,
    marginLeft: -157,
    width: 343,
    fontSize: FontSize.size_lg,
    top: "50%",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    left: "50%",
    color: Color.ew,
    textAlign: "left",
    position: "absolute",
  },
  cancel: {
    marginLeft: -35,
    width: 70,
  },
  button: {
    top: 164,
    height: 54,
    width: 168,
    backgroundColor: Color.ew,
    borderRadius: Border.br_17xl,
    left: 36,
  },
  buttonChild: {
    backgroundColor: "transparent",
    borderRadius: Border.br_17xl,
    left: 0,
    top: 0,
  },
  yesLogout: {
    marginLeft: -52,
    width: 107,
  },
  button1: {
    left: 226,
    top: 164,
    height: 54,
    width: 168,
  },
  logoutRectangle: {
    top: 662,
    borderTopLeftRadius: Border.br_16xl,
    borderTopRightRadius: Border.br_16xl,
    height: 266,
    backgroundColor: Color.iOSFFFFFF,
  },
  logoutRectangleWrapper: {
    backgroundColor: "rgba(83, 88, 97, 0.9)",
    top: 0,
    height: 928,
  },
  logoutPage: {
    flex: 1,
    width: "100%",
    overflow: "hidden",
    height: 928,
    backgroundColor: Color.iOSFFFFFF,
  },
});

export default LogoutPage;
