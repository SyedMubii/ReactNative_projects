import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import { Color, FontFamily, FontSize, Padding, Border } from "../GlobalStyles";

const HelpCenterContactUs = () => {
  return (
    <View style={styles.helpCenterContactUs}>
      <View style={styles.searchBar}>
        <View style={styles.view}>
          <Image
            style={styles.vectorIcon}
            contentFit="cover"
            source={require("../assets/vector71.png")}
          />
          <Text style={[styles.customerService, styles.websiteTypo]}>
            Customer Service
          </Text>
        </View>
        <View style={styles.view1}>
          <Image
            style={styles.vectorIcon1}
            contentFit="cover"
            source={require("../assets/vector72.png")}
          />
          <Text style={[styles.whatsapp, styles.websiteTypo]}>WhatsApp</Text>
        </View>
        <View style={[styles.view2, styles.viewSpaceBlock]}>
          <Image
            style={styles.vectorIcon1}
            contentFit="cover"
            source={require("../assets/vector73.png")}
          />
          <Text style={[styles.website, styles.websiteTypo]}>Website</Text>
        </View>
        <View style={styles.viewSpaceBlock}>
          <Image
            style={styles.vectorIcon3}
            contentFit="cover"
            source={require("../assets/vector74.png")}
          />
          <Text style={[styles.facebook, styles.websiteTypo]}>Facebook</Text>
        </View>
        <View style={[styles.view2, styles.viewSpaceBlock]}>
          <Image
            style={styles.vectorIcon4}
            contentFit="cover"
            source={require("../assets/vector75.png")}
          />
          <Text style={[styles.facebook, styles.websiteTypo]}>Twitter</Text>
        </View>
        <View style={styles.view1}>
          <Image
            style={styles.vectorIcon1}
            contentFit="cover"
            source={require("../assets/vector76.png")}
          />
          <Text style={[styles.whatsapp, styles.websiteTypo]}>Instagram</Text>
        </View>
      </View>
      <View style={styles.faqButton}>
        <View style={styles.faqButtonChild} />
        <Text style={[styles.contactUs, styles.faqFlexBox]}>Contact us</Text>
        <View style={styles.faqButtonItem} />
        <Text style={[styles.faq, styles.faqFlexBox]}>FAQ</Text>
      </View>
      <View style={styles.peopleBusService}>
        <Image
          style={[styles.vectorIcon6, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector68.png")}
        />
        <Text style={[styles.helpCenter, styles.timeTypo]}>Help Center</Text>
        <Image
          style={[styles.vectorIcon7, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector69.png")}
        />
      </View>
      <View style={styles.statusBar}>
        <View style={[styles.action, styles.timeLayout]}>
          <Text style={[styles.time, styles.timeLayout]}>9:41</Text>
        </View>
        <Image
          style={styles.containerIcon}
          contentFit="cover"
          source={require("../assets/container2.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  websiteTypo: {
    width: 231,
    display: "flex",
    textAlign: "left",
    color: Color.iOSFFFFFF,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.iOSDefaultTitle2_size,
    alignItems: "center",
  },
  viewSpaceBlock: {
    paddingHorizontal: Padding.p_lg,
    marginTop: 43,
    paddingVertical: Padding.p_mid,
    flexDirection: "row",
    height: 67,
    backgroundColor: Color.colorTomato_600,
    borderRadius: Border.br_3xs,
    width: 380,
  },
  faqFlexBox: {
    height: 19,
    display: "flex",
    textAlign: "left",
    alignItems: "center",
    position: "absolute",
  },
  vectorIconLayout: {
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    position: "absolute",
  },
  timeTypo: {
    textAlign: "center",
    lineHeight: 18,
    letterSpacing: 0,
    left: 0,
    color: Color.ew,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
  },
  timeLayout: {
    width: 54,
    position: "absolute",
  },
  vectorIcon: {
    height: 25,
    width: 25,
  },
  customerService: {
    marginLeft: 19,
  },
  view: {
    padding: Padding.p_mid,
    flexDirection: "row",
    height: 67,
    backgroundColor: Color.colorTomato_600,
    borderRadius: Border.br_3xs,
    alignItems: "center",
    width: 380,
  },
  vectorIcon1: {
    width: 22,
    height: 22,
  },
  whatsapp: {
    marginLeft: 20,
  },
  view1: {
    paddingHorizontal: Padding.p_lgi,
    marginTop: 43,
    paddingVertical: Padding.p_mid,
    flexDirection: "row",
    height: 67,
    backgroundColor: Color.colorTomato_600,
    borderRadius: Border.br_3xs,
    alignItems: "center",
    width: 380,
  },
  website: {
    marginLeft: 21,
  },
  view2: {
    alignItems: "center",
  },
  vectorIcon3: {
    width: 24,
    height: 24,
  },
  facebook: {
    marginLeft: 18,
  },
  vectorIcon4: {
    height: 20,
    width: 25,
  },
  searchBar: {
    top: 220,
    left: 26,
    alignItems: "center",
    width: 380,
    position: "absolute",
  },
  faqButtonChild: {
    top: 34,
    left: 192,
    backgroundColor: Color.ew,
    width: 190,
    height: 4,
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  contactUs: {
    top: 1,
    left: 244,
    fontSize: FontSize.iOSDefaultBody_size,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    width: 100,
    color: Color.ew,
    height: 19,
  },
  faqButtonItem: {
    top: 35,
    backgroundColor: Color.colorDarkgray_200,
    width: 192,
    height: 2,
    left: 0,
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  faq: {
    left: 80,
    fontSize: FontSize.size_lgi,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    color: Color.colorDarkgray_200,
    width: 41,
    top: 0,
  },
  faqButton: {
    top: 143,
    left: 21,
    width: 382,
    height: 38,
    position: "absolute",
  },
  vectorIcon6: {
    height: "66.67%",
    width: "4.39%",
    top: "33.33%",
    right: "95.53%",
    bottom: "0%",
    left: "0.08%",
  },
  helpCenter: {
    bottom: 0,
    fontSize: FontSize.size_6xl,
    width: 229,
    position: "absolute",
  },
  vectorIcon7: {
    height: "91.15%",
    width: "6.86%",
    top: "0%",
    right: "0%",
    bottom: "8.85%",
    left: "93.14%",
  },
  peopleBusService: {
    top: 81,
    left: 32,
    width: 368,
    height: 24,
    position: "absolute",
  },
  time: {
    fontSize: FontSize.size_mini,
    textAlign: "center",
    lineHeight: 18,
    letterSpacing: 0,
    left: 0,
    color: Color.ew,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    top: 0,
  },
  action: {
    top: 14,
    left: 20,
    height: 18,
  },
  containerIcon: {
    marginTop: -5.84,
    top: "50%",
    right: 15,
    width: 67,
    height: 12,
    position: "absolute",
  },
  statusBar: {
    marginLeft: -183,
    top: 9,
    left: "50%",
    width: 375,
    height: 44,
    position: "absolute",
  },
  helpCenterContactUs: {
    backgroundColor: Color.iOSFFFFFF,
    flex: 1,
    width: "100%",
    height: 975,
  },
});

export default HelpCenterContactUs;
