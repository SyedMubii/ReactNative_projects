import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Border, Color, FontFamily, FontSize } from "../GlobalStyles";

const NotificationPage = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.notificationPage, styles.iconLayout1]}>
      <View style={styles.options}>
        <View style={[styles.button9Parent, styles.parentLayout]}>
          <Image
            style={[styles.button9Icon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/button-9.png")}
          />
          <Text style={[styles.newServiceAvailable, styles.newClr]}>
            New Service Available
          </Text>
        </View>
        <View style={[styles.button10Parent, styles.parentLayout]}>
          <Image
            style={[styles.button10Icon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/button-9.png")}
          />
          <Text style={[styles.newTipsAvailable, styles.notificationLayout]}>
            New Tips Available
          </Text>
        </View>
        <View style={[styles.button7Parent, styles.parentLayout]}>
          <Image
            style={[styles.button7Icon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/button-7.png")}
          />
          <Text style={[styles.appUpdates, styles.newClr]}>App Updates</Text>
        </View>
        <View style={[styles.button8Parent, styles.parentLayout]}>
          <Image
            style={[styles.button7Icon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/button-9.png")}
          />
          <Text style={[styles.cashback, styles.newClr]}>Cashback</Text>
        </View>
        <View style={[styles.button5Parent, styles.parentLayout]}>
          <Image
            style={[styles.button10Icon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/button-7.png")}
          />
          <Text style={[styles.payments, styles.newClr]}>Payments</Text>
        </View>
        <View style={[styles.button6Parent, styles.parentLayout]}>
          <Image
            style={[styles.button7Icon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/button-9.png")}
          />
          <Text
            style={[styles.promoDiscount, styles.newClr]}
          >{`Promo & Discount`}</Text>
        </View>
        <View style={[styles.button3Parent, styles.parentLayout]}>
          <Image
            style={[styles.button9Icon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/button-7.png")}
          />
          <Text style={[styles.specialOffers, styles.newClr]}>
            Special Offers
          </Text>
        </View>
        <View style={[styles.button4Parent, styles.parentLayout]}>
          <Image
            style={[styles.button10Icon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/button-9.png")}
          />
          <Text style={[styles.vibrate, styles.newClr]}>Vibrate</Text>
        </View>
        <View style={[styles.button2Parent, styles.parentLayout]}>
          <Image
            style={[styles.button9Icon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/button-7.png")}
          />
          <Text style={[styles.sound, styles.newClr]}>Sound</Text>
        </View>
        <View style={styles.button1Parent}>
          <Image
            style={[styles.button9Icon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/button-7.png")}
          />
          <Text style={[styles.generalNotification, styles.newClr]}>
            General Notification
          </Text>
        </View>
      </View>
      <View style={[styles.notification, styles.notificationLayout]}>
        <Text style={[styles.notification1, styles.timeTypo]}>
          Notification
        </Text>
        <Pressable
          style={styles.vector}
          onPress={() => navigation.navigate("ProfilePage")}
        >
          <Image
            style={[styles.icon, styles.iconLayout1]}
            contentFit="cover"
            source={require("../assets/vector38.png")}
          />
        </Pressable>
      </View>
      <View style={styles.statusBar}>
        <View style={[styles.action, styles.timeLayout]}>
          <Text style={[styles.time, styles.timeLayout]}>9:41</Text>
        </View>
        <Image
          style={styles.containerIcon}
          contentFit="cover"
          source={require("../assets/container.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout1: {
    overflow: "hidden",
    width: "100%",
  },
  parentLayout: {
    height: 33,
    left: 0,
    width: 373,
    position: "absolute",
  },
  iconLayout: {
    height: 24,
    width: 44,
    borderRadius: Border.br_mini,
    left: 329,
    position: "absolute",
  },
  newClr: {
    color: Color.ew,
    left: 0,
  },
  notificationLayout: {
    width: 193,
    position: "absolute",
  },
  timeTypo: {
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    top: 0,
  },
  timeLayout: {
    width: 54,
    position: "absolute",
  },
  button9Icon: {
    top: 5,
  },
  newServiceAvailable: {
    width: 227,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_xl,
    color: Color.ew,
    top: 0,
    height: 33,
    position: "absolute",
  },
  button9Parent: {
    top: 523,
  },
  button10Icon: {
    top: 4,
  },
  newTipsAvailable: {
    textAlign: "left",
    color: Color.ew,
    left: 0,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_xl,
    top: 0,
    height: 33,
  },
  button10Parent: {
    top: 589,
  },
  button7Icon: {
    top: 3,
  },
  appUpdates: {
    width: 135,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_xl,
    color: Color.ew,
    top: 0,
    height: 33,
    position: "absolute",
  },
  button7Parent: {
    top: 458,
  },
  cashback: {
    width: 105,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_xl,
    color: Color.ew,
    top: 0,
    height: 33,
    position: "absolute",
  },
  button8Parent: {
    top: 392,
  },
  payments: {
    width: 104,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_xl,
    color: Color.ew,
    top: 0,
    height: 33,
    position: "absolute",
  },
  button5Parent: {
    top: 327,
  },
  promoDiscount: {
    width: 184,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_xl,
    color: Color.ew,
    top: 0,
    height: 33,
    position: "absolute",
  },
  button6Parent: {
    top: 262,
  },
  specialOffers: {
    width: 142,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_xl,
    color: Color.ew,
    top: 0,
    height: 33,
    position: "absolute",
  },
  button3Parent: {
    top: 196,
  },
  vibrate: {
    width: 76,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_xl,
    color: Color.ew,
    top: 0,
    height: 33,
    position: "absolute",
  },
  button4Parent: {
    top: 131,
  },
  sound: {
    width: 66,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_xl,
    color: Color.ew,
    top: 0,
    height: 33,
    position: "absolute",
  },
  button2Parent: {
    top: 65,
  },
  generalNotification: {
    width: 206,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_xl,
    color: Color.ew,
    top: 0,
    height: 33,
    position: "absolute",
  },
  button1Parent: {
    top: 0,
    height: 33,
    left: 0,
    width: 373,
    position: "absolute",
  },
  options: {
    top: 165,
    left: 31,
    height: 622,
    width: 373,
    position: "absolute",
  },
  notification1: {
    left: 29,
    fontSize: FontSize.size_7xl,
    color: Color.colorGray_400,
    width: 164,
    textAlign: "left",
    position: "absolute",
  },
  icon: {
    height: "100%",
    maxWidth: "100%",
    maxHeight: "100%",
  },
  vector: {
    left: "0%",
    top: "33.33%",
    right: "94.77%",
    bottom: "26.59%",
    width: "5.23%",
    height: "40.08%",
    position: "absolute",
  },
  notification: {
    top: 74,
    left: 26,
    height: 39,
  },
  time: {
    fontSize: FontSize.size_mini,
    letterSpacing: 0,
    lineHeight: 18,
    textAlign: "center",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    top: 0,
    color: Color.ew,
    left: 0,
  },
  action: {
    top: 14,
    left: 20,
    height: 18,
  },
  containerIcon: {
    marginTop: -5.84,
    top: "50%",
    right: 15,
    width: 67,
    height: 12,
    position: "absolute",
  },
  statusBar: {
    marginLeft: -183,
    top: 9,
    left: "50%",
    width: 375,
    height: 44,
    position: "absolute",
  },
  notificationPage: {
    backgroundColor: Color.iOSFFFFFF,
    flex: 1,
    height: 928,
  },
});

export default NotificationPage;
