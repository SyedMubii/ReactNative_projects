import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const ProfileEdit = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.profileEdit}>
      <LinearGradient
        style={styles.button}
        locations={[0, 1]}
        colors={["rgba(240, 0, 0, 0.96)", "#dc281e"]}
      >
        <Text style={[styles.update, styles.text1FlexBox]}>Update</Text>
      </LinearGradient>
      <View style={[styles.gender, styles.nameLayout]}>
        <Text style={[styles.female, styles.text1Typo]}>Female</Text>
        <Image
          style={[styles.vectorIcon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/vector47.png")}
        />
      </View>
      <View style={[styles.dateOfBirth, styles.emailPosition]}>
        <View style={[styles.dateOfBirthChild, styles.nameLayout]} />
        <Text style={styles.text}>02/3/2001</Text>
        <Text style={[styles.text4, styles.textTypo]} />
        <Image
          style={[styles.vectorIcon1, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/vector48.png")}
        />
      </View>
      <View style={[styles.phone, styles.nameLayout]}>
        <Text style={[styles.text1, styles.text1Typo]}>0312-3456789</Text>
        <Image
          style={[styles.vectorIcon2, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector49.png")}
        />
        <Image
          style={styles.image1Icon}
          contentFit="cover"
          source={require("../assets/image-1.png")}
        />
      </View>
      <View style={[styles.state, styles.nameLayout]}>
        <Text style={[styles.states, styles.statesPosition]}>States</Text>
        <Image
          style={[styles.vectorIcon3, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector49.png")}
        />
      </View>
      <View style={[styles.email, styles.emailPosition]}>
        <Text style={[styles.haha828087gmailcom, styles.statesPosition]}>
          Haha828087@gmail.com
        </Text>
        <Text style={[styles.text3, styles.textTypo]} />
        <Image
          style={styles.emailChild}
          contentFit="cover"
          source={require("../assets/group-6952.png")}
        />
      </View>
      <View style={[styles.lastName, styles.nameLayout]}>
        <Text style={[styles.rose, styles.roseTypo]}>{`Rose `}</Text>
      </View>
      <View style={[styles.userName, styles.nameLayout]}>
        <Text style={[styles.lesa, styles.roseTypo]}>{`Lesa `}</Text>
      </View>
      <Text style={[styles.editProfile, styles.timeTypo]}>Edit Profile</Text>
      <Pressable
        style={styles.vector}
        onPress={() => navigation.navigate("ProfilePage")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/vector50.png")}
        />
      </Pressable>
      <View style={styles.statusBar}>
        <View style={[styles.action, styles.timeLayout]}>
          <Text style={[styles.time, styles.timeLayout]}>9:41</Text>
        </View>
        <Image
          style={styles.containerIcon}
          contentFit="cover"
          source={require("../assets/container.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  text1FlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  nameLayout: {
    height: 51,
    width: 355,
    borderWidth: 1,
    borderColor: Color.colorWhitesmoke_300,
    borderStyle: "solid",
    borderRadius: Border.br_17xl,
    position: "absolute",
  },
  text1Typo: {
    height: 24,
    fontSize: FontSize.iOSMediumBody_size,
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
  },
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  emailPosition: {
    width: 355,
    left: 32,
    position: "absolute",
  },
  textTypo: {
    fontFamily: FontFamily.poppinsRegular,
    color: Color.ew,
    fontSize: FontSize.iOSMediumBody_size,
    textAlign: "left",
    position: "absolute",
  },
  vectorIconLayout: {
    bottom: "36.76%",
    top: "46.24%",
    maxHeight: "100%",
    maxWidth: "100%",
    width: "4.09%",
    height: "17%",
    position: "absolute",
    overflow: "hidden",
  },
  statesPosition: {
    left: 55,
    textAlign: "left",
    position: "absolute",
  },
  roseTypo: {
    left: 25,
    color: Color.ew,
    fontSize: FontSize.iOSMediumBody_size,
    textAlign: "left",
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    position: "absolute",
  },
  timeTypo: {
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
  },
  timeLayout: {
    width: 54,
    position: "absolute",
  },
  update: {
    marginLeft: -38.5,
    fontSize: FontSize.size_xl,
    color: Color.iOSFFFFFF,
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    textAlign: "left",
    left: "50%",
    top: 12,
  },
  button: {
    top: 772,
    left: 63,
    width: 321,
    height: 54,
    backgroundColor: "transparent",
    borderRadius: Border.br_17xl,
    position: "absolute",
  },
  female: {
    color: "#b4b4b4",
    width: 160,
    height: 24,
    left: 59,
    top: 13,
    textAlign: "left",
    position: "absolute",
  },
  vectorIcon: {
    top: "47.5%",
    right: "88.87%",
    bottom: "35.5%",
    left: "7.04%",
    width: "4.09%",
    height: "17%",
    maxWidth: "100%",
    position: "absolute",
  },
  gender: {
    top: 617,
    left: 32,
    height: 51,
  },
  dateOfBirthChild: {
    top: 11,
    left: 0,
  },
  text: {
    top: 25,
    color: Color.ew,
    fontSize: FontSize.iOSMediumBody_size,
    left: 59,
    textAlign: "left",
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    position: "absolute",
  },
  text4: {
    left: 190,
    top: 0,
  },
  vectorIcon1: {
    height: "37.36%",
    width: "6.2%",
    top: "39.2%",
    right: "87.04%",
    bottom: "23.44%",
    left: "6.76%",
    position: "absolute",
  },
  dateOfBirth: {
    top: 529,
    height: 62,
  },
  text1: {
    left: 73,
    color: Color.ew,
    width: 160,
    height: 24,
    top: 13,
    textAlign: "left",
    position: "absolute",
  },
  vectorIcon2: {
    right: "81.83%",
    left: "14.08%",
  },
  image1Icon: {
    top: 17,
    left: 14,
    width: 27,
    height: 16,
    position: "absolute",
  },
  phone: {
    top: 452,
    left: 32,
    height: 51,
  },
  states: {
    color: Color.ew,
    height: 24,
    fontSize: FontSize.iOSMediumBody_size,
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    width: 160,
    top: 12,
  },
  vectorIcon3: {
    right: "89.43%",
    left: "6.48%",
  },
  state: {
    top: 375,
    left: 32,
    height: 51,
  },
  haha828087gmailcom: {
    width: 212,
    top: 14,
    color: Color.ew,
    height: 24,
    fontSize: FontSize.iOSMediumBody_size,
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
  },
  text3: {
    left: 72,
    top: 14,
  },
  emailChild: {
    top: 15,
    width: 22,
    height: 22,
    left: 20,
    position: "absolute",
  },
  email: {
    top: 296,
    height: 53,
    borderWidth: 1,
    borderColor: Color.colorWhitesmoke_300,
    borderStyle: "solid",
    width: 355,
    borderRadius: Border.br_17xl,
  },
  rose: {
    top: 12,
  },
  lastName: {
    top: 219,
    left: 32,
    height: 51,
  },
  lesa: {
    top: 13,
  },
  userName: {
    top: 142,
    left: 32,
    height: 51,
  },
  editProfile: {
    top: 74,
    fontSize: FontSize.size_7xl,
    color: Color.colorGray_400,
    width: 202,
    left: 55,
    textAlign: "left",
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
    maxWidth: "100%",
  },
  vector: {
    left: "6.07%",
    top: "9.38%",
    right: "91.57%",
    bottom: "88.94%",
    width: "2.36%",
    height: "1.68%",
    position: "absolute",
  },
  time: {
    fontSize: FontSize.size_mini,
    letterSpacing: 0,
    lineHeight: 18,
    textAlign: "center",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    top: 0,
    color: Color.ew,
    left: 0,
  },
  action: {
    height: 18,
    left: 20,
    top: 14,
  },
  containerIcon: {
    marginTop: -5.84,
    top: "50%",
    right: 15,
    width: 67,
    height: 12,
    position: "absolute",
  },
  statusBar: {
    marginLeft: -183,
    top: 9,
    width: 375,
    height: 44,
    left: "50%",
    position: "absolute",
  },
  profileEdit: {
    backgroundColor: Color.iOSFFFFFF,
    flex: 1,
    height: 977,
    overflow: "hidden",
    width: "100%",
  },
});

export default ProfileEdit;
